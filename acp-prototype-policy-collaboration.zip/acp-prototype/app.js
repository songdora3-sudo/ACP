/* ACP 智能体控制平面 · 交互原型
 * 结构、命名与文案对齐 control-plane-sit 环境的真实前端（Vue3 + Ant Design Vue）。
 * 本文件用原生 JS 复刻外壳、路由、列表、向导、抽屉与弹窗交互，数据为演示数据。
 */
(function () {
  const D = window.ACP_DATA;
  const SYS_WS = 'acp-ws-sys';
  // file:// 打开时部分浏览器会禁用 localStorage，这里做一次安全兜底。
  const store = {
    get(k, d) { try { return localStorage.getItem(k) ?? d; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch { /* ignore */ } },
  };

  const state = {
    route: 'overview',
    locale: store.get('acp-prototype-locale', 'zh-CN'),
    wsCode: store.get('acp-prototype-ws', 'ws-agent-ops'),
    identity: store.get('acp-prototype-identity', 'auto'),
    user: { name: '张三', itCode: 'zhangsan3', email: 'zhangsan3@lenovo.com' },
    helpOpen: false,
    overlay: null,          // { type:'drawer'|'modal', key, data }
    filters: {},
    intakeTab: 'all',
    wizard: { step: 1, tab: 'model' },
    toast: null,
  };

  /* ------------------------------ i18n（原型仅覆盖框架级文案） ------------------------------ */
  const EN = {
    '概览': 'Overview', '智能体管理': 'Agents', '智能体流程管理': 'Workflows', '智能体资源管理': 'Resources',
    '观测洞察': 'Observability', '系统设置': 'Settings', '概览仪表盘': 'Overview', '系统仪表盘': 'System Dashboard',
    '智能体列表': 'Agent List', '智能体注册': 'Agent Registration', '智能体审批': 'Agent Approval',
    '智能体拓扑图': 'Agent Topology', '智能流程列表': 'Workflow List', '流程全局视图': 'Workflow Global View',
    'MCP 服务与工具': 'MCP Services & Tools', '知识库列表': 'Knowledge Bases', '模型接入管理': 'Model Access',
    '智能体KPI数据': 'Agent KPI', 'KPI数据维护': 'KPI Maintenance', '空间管理': 'Workspaces', '用户管理': 'Users',
    '刷新': 'Refresh', '新增': 'Add', '新建流程': 'New Workflow', '创建空间': 'New Workspace', '添加用户': 'Add User',
    '重置': 'Reset', '返回列表': 'Back to List', '下一步': 'Next', '上一步': 'Previous', '提交申请': 'Submit',
    '取消': 'Cancel', '保存': 'Save', '编辑': 'Edit', '详情': 'Detail', '删除': 'Delete', '通过': 'Approve',
    '驳回': 'Reject', '启用': 'Enable', '禁用': 'Disable', '关闭': 'Close', '创建': 'Create', '查看详情': 'Detail',
    '空间': 'Workspace', '帮助': 'Help', '退出登录': 'Sign out', '语言': 'Language', '原型使用说明': 'Prototype guide',
  };
  const t = (s) => (state.locale === 'en-US' ? (EN[s] || s) : s);

  /* ------------------------------ 图标 ------------------------------ */
  const ICONS = {
    overview: 'M12 4a8 8 0 100 16 8 8 0 000-16zm0 5.5a2.5 2.5 0 110 5 2.5 2.5 0 010-5z',
    dashboard: 'M4 4h7v7H4zM13 4h7v4h-7zM13 10h7v10h-7zM4 13h7v7H4z',
    list: 'M4 5h16M4 12h16M4 19h16',
    register: 'M14 3H6v18h12V7zM14 3v4h4M9 13h6M12 10v6',
    approval: 'M6 3h9l4 4v14H6zM15 3v4h4M9 14l2 2 4-4',
    topology: 'M9 3h6v4H9zM3 17h6v4H3zM15 17h6v4h-6zM12 7v5M6 17v-5h12v5',
    flow: 'M5 5h14M5 12h14M5 19h14',
    flowGlobal: 'M8 4h8v4H8zM3 16h6v4H3zM15 16h6v4h-6zM12 8v4M6 16v-4h12v4',
    inbox: 'M4 4h16v11l-4 5H8l-4-5zM4 15h5l1 2h4l1-2h5M9 9l3-3 3 3',
    flag: 'M6 21V4M6 4h11l-2 4 2 4H6',
    value: 'M12 3v18M8 7h6a3 3 0 010 6H8m0 0h7',
    mcp: 'M12 3v18M3 12h18M6 6l12 12M18 6L6 18',
    knowledge: 'M4 4h7v16H4zM13 4h7v16h-7z',
    model: 'M12 3l8 4.5v9L12 21l-8-4.5v-9zM12 3v18M4 7.5l16 9M20 7.5l-16 9',
    kpi: 'M4 20h16M7 16V9M12 16V5M17 16v-4',
    kpiMaint: 'M5 4h14v16H5zM8 9h8M8 13h5',
    workspace: 'M4 6h7v5H4zM13 6h7v5h-7zM4 13h16v5H4z',
    users: 'M9 11a3.5 3.5 0 100-7 3.5 3.5 0 000 7zm7 0a3 3 0 100-6 3 3 0 000 6zM3 20c0-3 2.7-5 6-5s6 2 6 5M17 15c2.4.3 4 2 4 5',
    refresh: 'M20 12a8 8 0 11-2.3-5.6M20 4v4h-4',
    search: 'M11 4a7 7 0 105 11.9L20 20M11 11h.01',
    plus: 'M12 5v14M5 12h14',
    check: 'M5 12l5 5 9-10',
    close: 'M6 6l12 12M18 6L6 18',
    eye: 'M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6-10-6-10-6zm10 2.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5z',
    history: 'M12 7v5l4 2M3 12a9 9 0 1015-6.7M3 4v5h5',
    trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13',
    flowSmall: 'M8 6h12M8 12h12M8 18h12M3 6h1M3 12h1M3 18h1',
  };
  const icon = (name, size) => `<svg class="nav__icon" width="${size || 16}" height="${size || 16}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="${ICONS[name] || ICONS.list}"/></svg>`;

  /* ------------------------------ 菜单（对齐真实路由 meta.menu） ------------------------------ */
  const NAV = [
    { key: 'home', items: [
      { key: 'overview', title: '概览仪表盘', icon: 'overview', visible: (c) => c.wsCode !== SYS_WS },
      { key: 'system-dashboard', title: '系统仪表盘', icon: 'dashboard', visible: (c) => c.wsCode === SYS_WS },
    ] },
    { key: 'agents', title: '智能体管理', items: [
      { key: 'agent-list', title: '智能体列表', icon: 'list' },
      { key: 'agent-register', title: '智能体注册', icon: 'register' },
      { key: 'agent-approval', title: '智能体审批', icon: 'approval' },
      { key: 'agent-topology', title: '智能体拓扑图', icon: 'topology' },
    ] },
    { key: 'workflows', title: '规划流程', tip: '增强', items: [
      { key: 'plan-overview', title: '规划总览', icon: 'overview' },
      { key: 'plan-workflows', title: '流程规划', icon: 'flow' },
      { key: 'plan-intake', title: '需求入口', icon: 'inbox' },
      { key: 'workflow-global', title: '流程全局视图', icon: 'flowGlobal' },
    ] },
    { key: 'resources', title: '智能体资源管理', items: [
      { key: 'mcp-services', title: 'MCP 服务与工具', icon: 'mcp' },
      { key: 'knowledge-bases', title: '知识库列表', icon: 'knowledge' },
      { key: 'model-access', title: '模型接入管理', icon: 'model' },
    ] },
    { key: 'collaboration', title: '协作管理', tip: 'DEMO', items: [
      { key: 'collab-list', title: '协作清单', icon: 'flowGlobal' },
      { key: 'collab-overview', title: '运行总览', icon: 'dashboard' },
      { key: 'collab-runs', title: '运行实例', icon: 'list' },
      { key: 'collab-errors', title: '异常记录', icon: 'history' },
    ] },
    { key: 'policies', title: '策略管理', tip: 'V0/V1', items: [
      { key: 'policy-overview', title: '策略总览', icon: 'dashboard' },
      { key: 'policy-list', title: '策略列表', icon: 'list' },
      { key: 'policy-assignments', title: '策略分配', icon: 'flow' },
      { key: 'policy-records', title: '执行记录', icon: 'history' },
      { key: 'policy-collab-admission', title: '协作准入与权限', icon: 'approval' },
      { key: 'policy-collab-control', title: '协作运行控制', icon: 'flow' },
      { key: 'policy-collab-hits', title: '协作命中与执行', icon: 'history' },
    ] },
    { key: 'observability', title: '观测洞察', items: [
      { key: 'agent-kpi', title: '智能体KPI数据', icon: 'kpi' },
      { key: 'kpi-maintenance', title: 'KPI数据维护', icon: 'kpiMaint' },
    ] },
    { key: 'settings', title: '系统设置', visible: (c) => c.role !== 'ws_basic', items: [
      { key: 'settings-tenants', title: '空间管理', icon: 'workspace', visible: (c) => c.wsCode === SYS_WS },
      { key: 'settings-users', title: '用户管理', icon: 'users' },
    ] },
  ];

  const ROUTE_TITLES = {
    "collab-list": ["协作管理", "协作关系", "协作清单"],
    "collab-detail": ["协作管理", "协作详情"],
    "collab-overview": ["协作管理", "协作运行", "运行总览"],
    "collab-runs": ["协作管理", "协作运行", "运行实例"],
    "collab-trace": ["协作管理", "执行追踪"],
    "collab-errors": ["协作管理", "异常记录"],
    "policy-collab-admission": ["策略管理", "协作策略", "准入与权限"],
    "policy-collab-control": ["策略管理", "协作策略", "运行控制"],
    "policy-collab-hits": ["策略管理", "协作策略", "命中与执行记录"],

    'policy-overview': ['策略管理', '策略总览'], 'policy-list': ['策略管理', '策略列表'],
    'policy-assignments': ['策略管理', '策略分配'], 'policy-records': ['策略管理', '执行记录'],
    overview: ['概览', '概览仪表盘'], 'system-dashboard': ['概览', '系统仪表盘'],
    'agent-list': ['智能体管理', '智能体列表'], 'agent-register': ['智能体管理', '智能体注册'],
    'agent-approval': ['智能体管理', '智能体审批'], 'agent-topology': ['智能体管理', '智能体拓扑图'],
    'plan-overview': ['规划流程', '规划总览'], 'plan-workflows': ['规划流程', '流程规划'],
    'plan-intake': ['规划流程', '需求入口'], 'workflow-global': ['规划流程', '流程全局视图'],
    'mcp-services': ['智能体资源管理', 'MCP 服务与工具'], 'knowledge-bases': ['智能体资源管理', '知识库列表'],
    'model-access': ['智能体资源管理', '模型接入管理'],
    'agent-kpi': ['观测洞察', '智能体KPI数据'], 'kpi-maintenance': ['观测洞察', 'KPI数据维护'],
    'settings-tenants': ['系统设置', '空间管理'], 'settings-users': ['系统设置', '用户管理'],
  };

  const ROLE_LABEL = { sys_admin: '平台管理员', ws_admin: '空间管理员', ws_basic: '空间用户' };

  const currentWorkspace = () => D.workspaces.find((w) => w.wsCode === state.wsCode) || D.workspaces[0];
  const currentRole = () => {
    if (state.identity !== 'auto') return state.identity;
    return currentWorkspace().userRole;
  };

  /* ------------------------------ 工具 ------------------------------ */
  const esc = (v) => String(v == null ? '' : v).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const relTime = (iso) => {
    const m = Math.max(1, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
    if (m < 60) return `${m}分钟前`;
    const h = Math.round(m / 60);
    if (h < 24) return `${h}小时前`;
    return `${Math.round(h / 24)}天前`;
  };
  const stamp = (iso) => String(iso).replace('T', ' ').slice(0, 16);
  const AVATAR_COLORS = ['#2563eb', '#0ea5a4', '#7c3aed', '#f59e0b', '#db2777', '#16a34a', '#0891b2'];
  const avatarColor = (s) => AVATAR_COLORS[[...String(s)].reduce((a, c) => a + c.charCodeAt(0), 0) % AVATAR_COLORS.length];

  const PLAN_CHIP = { PLANNED: ['chip--blue', '已规划'], SCHEDULED: ['chip--purple', '已排期'], WIP: ['chip--cyan', '进行中'], LIVE: ['chip--green', '已上线'], DEPRECATED: ['chip--grey', '已废弃'] };
  const AUDIT_CHIP = { DRAFT: ['chip--grey', '草稿'], REVIEWING: ['chip--orange', '审批中'], PUBLISHED: ['chip--green', '已发布'], REJECTED: ['chip--red', '已驳回'] };
  const PLAN_COLOR = { PLANNED: '#2563eb', SCHEDULED: '#7c3aed', WIP: '#0891b2', LIVE: '#059669', DEPRECATED: '#6b7280' };
  const chip = (cls, text, dot) => `<span class="chip ${cls}">${dot === false ? '' : '<i class="dot"></i>'}${esc(text)}</span>`;
  const planChip = (v) => chip((PLAN_CHIP[v] || ['chip--grey', v])[0], (PLAN_CHIP[v] || ['', v])[1]);
  const auditChip = (v) => chip((AUDIT_CHIP[v] || ['chip--grey', v])[0], (AUDIT_CHIP[v] || ['', v])[1]);

  const toast = (msg) => {
    state.toast = msg;
    const el = document.getElementById('toast');
    if (el) { el.textContent = msg; el.classList.remove('hidden'); }
    clearTimeout(toast._t);
    toast._t = setTimeout(() => { state.toast = null; const e2 = document.getElementById('toast'); if (e2) e2.classList.add('hidden'); }, 2200);
  };

  /* ------------------------------ 图表 ------------------------------ */
  function donut(items, colors, size) {
    const s = size || 190, r = s / 2 - 12, cx = s / 2, cy = s / 2;
    const total = items.reduce((a, b) => a + b.count, 0) || 1;
    let angle = -Math.PI / 2;
    const arcs = items.map((it, i) => {
      const sweep = (it.count / total) * Math.PI * 2;
      const x1 = cx + r * Math.cos(angle), y1 = cy + r * Math.sin(angle);
      angle += sweep;
      const x2 = cx + r * Math.cos(angle), y2 = cy + r * Math.sin(angle);
      const large = sweep > Math.PI ? 1 : 0;
      return `<path d="M${x1} ${y1}A${r} ${r} 0 ${large} 1 ${x2} ${y2}" fill="none" stroke="${colors[i % colors.length]}" stroke-width="24"/>`;
    }).join('');
    return `<div class="donut"><svg width="${s}" height="${s}" viewBox="0 0 ${s} ${s}">${arcs}
      <text x="${cx}" y="${cy - 2}" text-anchor="middle" font-size="24" font-weight="700" fill="#111827">${total}</text>
      <text x="${cx}" y="${cy + 18}" text-anchor="middle" font-size="12" fill="#98a1b0">${items.length} 分类</text></svg>
      <div class="legend">${items.map((it, i) => `<span><i style="background:${colors[i % colors.length]}"></i>${esc(it.name)} · ${it.count}</span>`).join('')}</div></div>`;
  }

  function hbars(items, color) {
    const max = Math.max(1, ...items.map((i) => i.count));
    return `<div class="bars">${items.map((i) => `<div class="bar-row"><span>${esc(i.name)}</span>
      <span class="bar-track"><i class="bar-fill" style="display:block;width:${(i.count / max) * 100}%;background:${typeof color === 'function' ? color(i) : color}"></i></span>
      <strong>${i.count}</strong></div>`).join('')}</div>`;
  }

  function vbars(items, color) {
    const max = Math.max(1, ...items.map((i) => i.count));
    return `<div class="vbars">${items.map((i) => `<div class="vbar"><span class="vbar__val">${i.count}</span>
      <span class="vbar__fill" style="height:${(i.count / max) * 76}%;background:${color}"></span><span>${esc(i.name)}</span></div>`).join('')}</div>`;
  }

  /* ------------------------------ 外壳 ------------------------------ */
  function renderSidebar() {
    const ctx = { wsCode: state.wsCode, role: currentRole() };
    const groups = NAV.filter((g) => !g.visible || g.visible(ctx)).map((g) => {
      const items = g.items.filter((it) => !it.visible || it.visible(ctx));
      if (!items.length) return '';
      return `<div class="nav__group">${g.title ? `<div class="nav__group-title">${esc(t(g.title))}${g.tip ? `<span class="nav__tip">${esc(g.tip)}</span>` : ''}</div>` : ''}
        ${items.map((it) => `<button class="nav__item ${state.route === it.key ? 'on' : ''}" data-nav="${it.key}">${icon(it.icon)}<span>${esc(t(it.title))}</span></button>`).join('')}</div>`;
    }).join('');
    return `<aside class="sidebar">
      <div class="sidebar__brand"><div class="sidebar__logo">ACP</div><div><strong>智能体管理平面</strong><span>Agent Control Plane</span></div></div>
      <nav class="nav">${groups}</nav></aside>`;
  }

  function renderTopbar() {
    const crumb = ROUTE_TITLES[state.route] || ['', ''];
    const ws = currentWorkspace();
    return `<header class="topbar">
      <div class="crumbs">${crumb.map((c, i) => `${i ? '<span>›</span>' : ''}${i === crumb.length - 1 ? `<b>${esc(t(c))}</b>` : esc(t(c))}`).join('')}</div>
      <div class="topbar__right">
        <span class="topbar__label">${t('空间')}</span>
        <div class="relative">
          <select class="select" style="width:180px" data-action="ws-switch">
            ${D.workspaces.map((w) => `<option value="${w.wsCode}" ${w.wsCode === state.wsCode ? 'selected' : ''}>${esc(w.wsName)}</option>`).join('')}
          </select>
        </div>
        <div class="seg">
          <button class="${state.locale === 'zh-CN' ? 'on' : ''}" data-action="locale" data-value="zh-CN">中</button>
          <button class="${state.locale === 'en-US' ? 'on' : ''}" data-action="locale" data-value="en-US">EN</button>
        </div>
        <button class="icon-btn" data-action="help" title="${t('帮助')}">?</button>
        <div class="relative">
          <button class="user-chip" data-action="user-menu">
            <span class="user-chip__avatar">张</span>
            <span class="user-chip__meta"><strong>${esc(state.user.name)}</strong><span>${esc(ROLE_LABEL[currentRole()])}</span></span>
            <span style="color:#98a1b0">⌄</span>
          </button>
          ${state.userMenu ? `
          <div class="drop">
            <div class="drop__title">切换身份（演示 RBAC）</div>
            <button class="${state.identity === 'auto' ? 'on' : ''}" data-action="identity" data-value="auto">跟随空间角色（${esc(ROLE_LABEL[currentWorkspace().userRole])}）</button>
            ${Object.entries(ROLE_LABEL).map(([k, v]) => `<button class="${state.identity === k ? 'on' : ''}" data-action="identity" data-value="${k}">${esc(v)}</button>`).join('')}
            <div class="drop__title" style="border-top:1px solid var(--line-soft)">账号</div>
            <button data-action="logout">退出登录</button>
          </div>` : ''}
        </div>
      </div>
    </header>`;
  }

  function renderShell(view) {
    return `<div class="shell">${renderSidebar()}
      <div><div class="topbar-wrap" style="position:sticky;top:0;z-index:20">${renderTopbar()}</div>
      <main class="content">${view}</main></div></div>`;
  }

  /* ------------------------------ 页面：概览 / 系统仪表盘 ------------------------------ */
  function pageOverview() {
    const o = D.overview;
    const metrics = [
      ['智能体总数', o.totalAgents, 'blue', 'list'],
      ['已审批', o.approvedCount, 'green', 'check'],
      ['待审批', o.pendingCount, 'orange', 'approval'],
      ['API总数', o.totalApiCount, 'cyan', 'mcp'],
      ['智能体总依赖数', o.totalDependencyCount, 'red', 'topology'],
      ['智能体技能总数', o.totalSkillCount, 'purple', 'kpi'],
    ];
    return `<div class="page-header"><div>
        <h1>概览仪表盘</h1>
        <p>当前空间：${esc(currentWorkspace().wsName)} · 展示空间内所有数据指标</p></div>
      <div class="page-header__actions"><span class="chip chip--blue">5 分钟更新</span>
        <button class="btn" data-action="refresh">${icon('refresh', 14)} ${t('刷新')}</button></div></div>
      <section class="metric-grid">${metrics.map(([label, value, tone, ic]) => `
        <article class="card metric"><span class="metric__icon tone-${tone}">${icon(ic, 18)}</span>
        <div><div class="metric__label">${esc(label)}</div><div class="metric__value">${value}</div></div></article>`).join('')}</section>
      <section class="grid-2">
        <article class="card"><div class="card-head"><h2>智能体网关类型统计</h2><p>按网关类型统计智能体数量</p></div>
          <div class="card-body">${vbars(o.gatewayTypes, '#2563eb')}</div></article>
        <article class="card"><div class="card-head"><h2>智能体部门分布</h2><p>共 ${o.departments.length} 个部门 · ${o.totalAgents} 个智能体</p></div>
          <div class="card-body">${hbars(o.departments.map((d) => ({ name: d.name, count: d.count })), '#0ea5a4')}</div></article>
        <article class="card"><div class="card-head"><h2>智能体规划状态统计</h2><p>按规划状态统计智能体数量</p></div>
          <div class="card-body">${vbars(o.planStatuses, '#0ea5a4')}</div></article>
        <article class="card"><div class="card-head"><h2>智能体模型分布</h2><p>按模型统计智能体数量</p></div>
          <div class="card-body">${donut(o.models.map((m) => ({ name: m.name, count: m.count })), ['#2563eb', '#0ea5a4', '#8b5cf6', '#f59e0b', '#ec4899', '#64748b'])}</div></article>
      </section>`;
  }

  function pageSystemDashboard() {
    const s = D.system;
    const metrics = [
      ['空间总数', s.spaceCount, 'blue', 'workspace'],
      ['智能体总数', s.totalAgents, 'green', 'list'],
      ['智能体待审批数', s.pendingAgentCount, 'orange', 'approval'],
      ['智能体已发布数', s.publishedAgentCount, 'purple', 'check'],
      ['智能体API总数', s.totalApiCount, 'cyan', 'mcp'],
      ['智能体技能总数', s.totalSkillCount, 'red', 'kpi'],
    ];
    return `<div class="page-header"><div>
        <h1>系统仪表盘</h1><p>展示空间总数、智能体统计、API 总数及多维度分布图表</p></div>
      <div class="page-header__actions"><span class="chip chip--blue">每 5 分钟自动刷新</span>
        <button class="btn" data-action="refresh">${icon('refresh', 14)} ${t('刷新')}</button></div></div>
      <section class="metric-grid">${metrics.map(([label, value, tone, ic]) => `
        <article class="card metric"><span class="metric__icon tone-${tone}">${icon(ic, 18)}</span>
        <div><div class="metric__label">${esc(label)}</div><div class="metric__value">${value}</div></div></article>`).join('')}</section>
      <section class="grid-2">
        <article class="card"><div class="card-head"><h2>智能体审核状态分布</h2><p>按审核状态统计智能体数量</p></div>
          <div class="card-body">${vbars(s.auditStatuses, '#2563eb')}</div></article>
        <article class="card"><div class="card-head"><h2>智能体模型分布</h2><p>按模型统计智能体数量</p></div>
          <div class="card-body">${donut(D.overview.models, ['#2563eb', '#0ea5a4', '#8b5cf6', '#f59e0b', '#ec4899', '#64748b'])}</div></article>
        <article class="card"><div class="card-head"><h2>基于空间的人数统计</h2><p>按空间统计用户人数</p></div>
          <div class="card-body">${hbars(s.workspaceUsers, '#2563eb')}</div></article>
        <article class="card"><div class="card-head"><h2>基于空间智能体数的统计</h2><p>按空间统计智能体数量</p></div>
          <div class="card-body">${hbars(s.workspaceAgents, '#0ea5a4')}</div></article>
        <article class="card"><div class="card-head"><h2>基于规划状态的智能体分类统计</h2><p>按规划状态统计智能体数量</p></div>
          <div class="card-body">${vbars(D.overview.planStatuses, '#0ea5a4')}</div></article>
      </section>`;
  }

  /* ------------------------------ 页面：智能体列表 ------------------------------ */
  function filterAgents() {
    const f = state.filters.agents || {};
    return D.agents.filter((a) => {
      const kw = (f.keyword || '').trim().toLowerCase();
      if (kw && !(a.name + a.agentCode + a.owner + a.id).toLowerCase().includes(kw)) return false;
      if (f.department && a.department !== f.department) return false;
      if (f.planStatus && a.planStatus !== f.planStatus) return false;
      if (f.auditStatus && a.auditStatus !== f.auditStatus) return false;
      return true;
    });
  }

  function pageAgentList() {
    const f = state.filters.agents || {};
    const rows = filterAgents();
    const canDelete = currentRole() !== 'ws_basic';
    const stats = [
      ['智能体数量', D.agents.length, 'blue', 'list'],
      ['已发布', D.agents.filter((a) => a.auditStatus === 'PUBLISHED').length, 'green', 'check'],
      ['审核中', D.agents.filter((a) => a.auditStatus === 'REVIEWING').length, 'orange', 'approval'],
      ['已驳回', D.agents.filter((a) => a.auditStatus === 'REJECTED').length, 'red', 'close'],
      ['API 总数', D.agents.reduce((n, a) => n + a.apiCount, 0), 'cyan', 'mcp'],
    ];
    return `<div class="page-header"><div><h1>智能体列表</h1>
        <p>展示当前空间内所有智能体（共 ${D.agents.length} 个）· 删除需管理员权限</p></div>
      <div class="page-header__actions"><button class="btn" data-action="refresh">${icon('refresh', 14)} ${t('刷新')}</button></div></div>
      ${currentRole() === 'ws_basic' ? '<div class="banner banner--warn">当前身份为空间用户：可查看与导出，删除智能体需空间管理员或平台管理员权限。</div>' : ''}
      <section class="metric-grid">${stats.map(([label, value, tone, ic]) => `
        <article class="card metric"><span class="metric__icon tone-${tone}">${icon(ic, 18)}</span>
        <div><div class="metric__label">${esc(label)}</div><div class="metric__value">${value}</div></div></article>`).join('')}</section>
      <section class="card">
        <div class="filter-bar">
          <input class="input" placeholder="搜索名称 / ID / Owner" value="${esc(f.keyword || '')}" data-filter="agents.keyword">
          <select class="select" data-filter="agents.department"><option value="">部门</option>
            ${D.departments.map((d) => `<option ${f.department === d ? 'selected' : ''}>${d}</option>`).join('')}</select>
          <select class="select" data-filter="agents.planStatus"><option value="">规划状态</option>
            ${Object.entries(PLAN_CHIP).map(([k, v]) => `<option value="${k}" ${f.planStatus === k ? 'selected' : ''}>${v[1]}</option>`).join('')}</select>
          <select class="select" data-filter="agents.auditStatus"><option value="">审核状态</option>
            ${Object.entries(AUDIT_CHIP).map(([k, v]) => `<option value="${k}" ${f.auditStatus === k ? 'selected' : ''}>${v[1]}</option>`).join('')}</select>
          <span class="filter-spacer"></span>
          <button class="btn" data-action="reset-filter" data-scope="agents">${icon('refresh', 14)} ${t('重置')}</button>
        </div>
        <div style="overflow:auto">
        <table class="data"><thead><tr>
          <th>智能体名称</th><th>部门</th><th>负责人</th><th>规划状态</th><th>审核状态</th><th>能力/技能</th><th>模型</th><th>版本号</th><th>API 数</th><th>最近同步</th><th>操作</th>
        </tr></thead><tbody>
        ${rows.length ? rows.map((a) => `<tr>
          <td><div class="cell-name"><span class="avatar-sq" style="background:${avatarColor(a.name)}">${esc(a.name.slice(0, 1))}</span>
            <div><div>${esc(a.name)}</div><small>${esc(a.agentCode)}</small></div></div></td>
          <td>${esc(a.department)}</td><td>${esc(a.owner)}</td>
          <td>${planChip(a.planStatus)}</td><td>${auditChip(a.auditStatus)}</td>
          <td><div style="display:flex;flex-wrap:wrap;gap:4px;max-width:190px">${a.skills.map((s) => `<span class="tag-plain">${esc(s)}</span>`).join('')}</div></td>
          <td>${esc(a.model)}</td><td>${esc(a.version)}</td><td>${a.apiCount}</td><td>${relTime(a.lastSyncAt)}</td>
          <td><div class="row-actions">
            <button class="icon-btn" data-action="agent-detail" data-id="${a.id}" title="详情">${icon('eye', 13)}</button>
            <button class="icon-btn" data-action="agent-edit" data-id="${a.id}" title="编辑">✎</button>
            <button class="icon-btn" data-action="agent-delete" data-id="${a.id}" title="删除" ${canDelete ? '' : 'disabled style="opacity:.45;cursor:not-allowed"'}>${icon('trash', 13)}</button>
            <button class="icon-btn" data-action="agent-history" data-id="${a.id}" title="智能体版本">${icon('history', 13)}</button>
            ${a.pendingChanges ? `<span class="chip chip--red" style="height:18px;padding:0 6px">${a.pendingChanges}</span>` : ''}
          </div></td></tr>`).join('') : `<tr><td colspan="11"><div class="empty">暂无智能体数据</div></td></tr>`}
        </tbody></table></div>
        <div class="table-foot"><span>共 ${rows.length} 条</span><div class="pager"><button class="on">1</button></div></div>
      </section>`;
  }

  /* ------------------------------ 页面：智能体注册 ------------------------------ */
  function pageAgentRegister() {
    const step = state.wizard.step;
    const tabs = [['model', '模型能力'], ['mcp', 'MCP'], ['skill', '技能'], ['knowledge', '知识库'], ['dependency', '依赖'], ['extension', '扩展']];
    const intro = {
      model: '配置一个或多个模型能力，为智能体提供对话、检索或嵌入等基础模型服务。',
      mcp: '配置 MCP Server 和暴露的 Tools，使智能体能够调用受控外部能力。',
      skill: '配置可复用的业务与插件能力，供智能体在运行时按需调用。',
      knowledge: '配置 RAG、向量、图谱或 FAQ 知识库，为智能体提供可信的知识检索能力。',
      dependency: '声明当前智能体需要协作调用的其他智能体与外部服务。',
      extension: '自定义平台扩展属性，例如框架、SDK 版本或部署方式。',
    };
    const field = (label, ph, req, full, value) => `<div class="field ${full ? 'full' : ''}">
      <label>${req ? '<span class="req">*</span>' : ''}${label}</label>
      <input class="input" placeholder="${ph}" value="${esc(value || '')}"></div>`;
    const select = (label, ph, req) => `<div class="field"><label>${req ? '<span class="req">*</span>' : ''}${label}</label>
      <select class="select"><option value="">${ph}</option><option>${ph.replace('选择', '示例')}</option></select></div>`;
    return `<div class="banner">填写注册申请并提交后，可前往左侧“智能体审批”菜单完成审批，观察 Non-Human Identity 生成与同步流程。</div>
      <div class="page-header"><div><h1>智能体注册</h1>
        <p>手工录入智能体信息 → 空间管理员审批 → 生成 Non-Human Identity 并同步 AI Gateway / Agent IAM → API 数据回流</p></div></div>
      <div class="wizard">
        <section class="card">
          <div style="display:flex;align-items:center;gap:8px;padding:16px 20px 0;font-weight:600">${icon('register', 16)} 智能体注册申请</div>
          <div class="steps">
            ${[['基本信息', 1], ['能力与技能', 2], ['提交', 3]].map(([label, n], i) => `${i ? '<span class="step-line"></span>' : ''}
              <span class="step ${step >= n ? 'on' : ''}"><span class="step__num">${n}</span>${label}</span>`).join('')}
          </div>
          ${step === 1 ? `
          <div class="form-grid">
            ${field('智能体标识', '如：customer_service', true, false, state.wizard.draftCode || '')}
            ${field('名称', '如：客服智能体', true)}
            ${field('展示名称', '如：AI 客服助手', true)}
            ${field('版本', '如：1.2.0', true)}
            ${field('所属部门', '填写所属部门', true)}
            ${select('业务分类', '选择业务分类', true)}
            ${field('负责人', '填写负责人姓名', true)}
            ${field('负责人邮箱', '如：jon@example.com', true)}
            ${select('网关类型', '选择网关类型', true)}
            ${select('数据中心', '选择数据中心', true)}
            ${field('服务入口', '如：https://agent.lenovo.com/customer-service', true)}
            <div class="field"><label><span class="req">*</span>CMDB</label>
              <div style="display:flex;gap:8px"><input class="input" placeholder="请选择 CMDB Application" readonly value="${esc(state.wizard.cmdb || '')}">
              <button class="btn btn-primary" data-action="cmdb">选择</button></div></div>
            ${select('规划状态', '选择规划状态', true)}
            ${select('运行状态', '选择运行状态', true)}
            ${field('分类组', '选择或输入分类组', false, true)}
            ${field('标签', '输入标签后回车，多个用逗号分隔', true, true)}
            <div class="field full"><label><span class="req">*</span>能力描述</label>
              <textarea class="textarea" placeholder="智能体做什么、服务谁"></textarea><span class="hint">0 / 200</span></div>
          </div>
          <div class="form-actions"><button class="btn btn-primary" data-action="wizard-next">${t('下一步')}</button></div>` : `
          <div class="tabs">${tabs.map(([k, label]) => `<button class="${state.wizard.tab === k ? 'on' : ''}" data-action="wizard-tab" data-value="${k}">${label}</button>`).join('')}</div>
          <div class="card-body">
            <p style="margin:0 0 14px;color:var(--text-sub);font-size:13px">${intro[state.wizard.tab]}</p>
            ${state.wizard.tab === 'model' ? `
              <div class="form-grid" style="padding:0">
                ${field('名称', '如：GPT-4.1', true)}${field('提供方', '如：OpenAI', true)}
                ${field('类型', '如：Chat', true)}${field('版本', '如：1.0.0', true)}
                ${field('链路类型', '如：APIH', true)}${field('用途', '如：主对话模型', true)}
                <div class="field full"><label>端点</label><input class="input" placeholder="如：https://api.example.com/v1"></div>
              </div>
              <button class="btn" data-action="noop">${icon('plus', 14)} 添加模型</button>` : `
              <div class="empty" style="padding:36px 12px"><span class="art">▦</span>${intro[state.wizard.tab]}<br>
              <button class="btn" style="margin-top:14px" data-action="noop">${icon('plus', 14)} 添加${tabs.find((x) => x[0] === state.wizard.tab)[1]}</button></div>`}
          </div>
          <div class="form-actions">
            <button class="btn" data-action="wizard-prev">${t('上一步')}</button>
            ${step === 2 ? '<button class="btn btn-primary" data-action="wizard-next">下一步</button>'
              : '<button class="btn btn-primary" data-action="wizard-submit">提交申请</button>'}
          </div>`}
        </section>
        <aside class="card">
          <div class="card-head"><h2>注册生命周期</h2></div>
          <div class="lifecycle"><ol>
            ${['手工录入智能体信息', '提交等待空间管理员审批', '审批通过 → 生成 Non-Human Identity', '同步 AI Gateway 与 Agent IAM', 'API 调用信息汇总回流']
              .map((s, i) => `<li class="${i === 0 ? 'on' : ''}">${s}</li>`).join('')}
          </ol>
          <div class="status-note">当前申请状态：等待空间管理员审批</div></div>
        </aside>
      </div>`;
  }

  /* ------------------------------ 页面：智能体审批 ------------------------------ */
  function pageAgentApproval() {
    const isSys = state.wsCode === SYS_WS;
    const canApprove = isSys ? currentRole() === 'sys_admin' : currentRole() === 'ws_admin';
    const rows = D.applications;
    return `<div class="banner">空间管理员审批注册申请；通过后系统将生成 Non-Human Identity 并同步至 AI Gateway 与 Agent IAM。</div>
      <div class="page-header"><div><h1>智能体审批</h1><p>查看并审批待处理的智能体注册申请。</p></div></div>
      <section class="card">
        <div class="card-body"><div class="banner" style="margin:0">${isSys ? '系统管理空间仅平台管理员可审批' : '仅当前空间管理员可审批'}</div></div>
        ${rows.length ? `<table class="data"><thead><tr><th>智能体名称</th><th>部门</th><th>负责人</th><th>登记时间</th><th>操作</th></tr></thead>
        <tbody>${rows.map((r) => `<tr>
          <td><div class="cell-name"><span class="avatar-sq" style="background:${avatarColor(r.name)}">${esc(r.name.slice(0, 1))}</span>
            <div><div>${esc(r.name)}</div><small>${esc(r.agentCode)}</small></div></div></td>
          <td><span class="tag-plain">${esc(r.department)}</span></td><td>${esc(r.owner)}</td><td>${stamp(r.createdAt)}</td>
          <td>${r.auditStatus === 'PENDING' ? `<div class="row-actions">
              <button class="btn btn-sm" data-action="approval-detail" data-id="${r.id}">查看详情</button>
              <button class="btn btn-sm btn-primary" data-action="approval-approve" data-id="${r.id}" ${canApprove ? '' : 'disabled'}>${icon('check', 12)} ${t('通过')}</button>
              <button class="btn btn-sm btn-danger" data-action="approval-reject" data-id="${r.id}" ${canApprove ? '' : 'disabled'}>${icon('close', 12)} ${t('驳回')}</button>
            </div>` : chip(r.auditStatus === 'ONLINE' ? 'chip--green' : r.auditStatus === 'REJECTED' ? 'chip--red' : 'chip--orange', r.auditStatus === 'ONLINE' ? '已上线' : r.auditStatus === 'REJECTED' ? '已驳回' : '同步中')}</td></tr>`).join('')}
        </tbody></table>` : '<div class="empty"><span class="art">🗂</span>当前没有待处理申请</div>'}
      </section>`;
  }

  /* ------------------------------ 页面：拓扑图 / 流程全局视图 ------------------------------ */
  const TYPE_COLOR = { agent: '#3157eb', workflow: '#7538dd', 'categoryGroup': '#C51FEA', mcp: '#12b886', model: '#8b5cf6', skill: '#fb8b19', knowledgebase: '#2563eb', service: '#df2b96', thirdParty: '#e55d6f', other: '#94a3b8' };
  const TYPE_LABEL = { agent: '智能体', workflow: '流程', 'categoryGroup': '分类组', mcp: 'MCP', model: '模型', skill: '技能', knowledgebase: '知识库', service: '服务', thirdParty: '第三方依赖', other: '其它' };

  function topoLayout(nodes) {
    // 环形种子 + 松弛迭代：保证节点不重叠且分布稳定（便于原型演示与截图）。
    const pos = {};
    const ring = (list, radius) => list.forEach((n, i) => {
      const angle = (-Math.PI / 2) + (i / Math.max(1, list.length)) * Math.PI * 2 + (list.length > 3 ? 0 : 0.6);
      pos[n.id] = [50 + radius * Math.cos(angle), 50 + radius * Math.sin(angle) * 0.85];
    });
    ring(nodes.filter((n) => n.type === 'agent'), 22);
    ring(nodes.filter((n) => n.type !== 'agent'), 40);

    const AX = 2.1, MIN = 13;
    for (let it = 0; it < 220; it += 1) {
      for (let i = 0; i < nodes.length; i += 1) {
        for (let j = i + 1; j < nodes.length; j += 1) {
          const a = pos[nodes[i].id], b = pos[nodes[j].id];
          const dx = (a[0] - b[0]) * AX, dy = a[1] - b[1];
          const d = Math.hypot(dx, dy) || 0.01;
          if (d < MIN) {
            const push = (MIN - d) / 2 / d;
            a[0] += (dx * push) / AX; a[1] += dy * push;
            b[0] -= (dx * push) / AX; b[1] -= dy * push;
          }
        }
      }
      nodes.forEach((n) => {
        const p = pos[n.id];
        p[0] = Math.min(93, Math.max(7, p[0]));
        p[1] = Math.min(86, Math.max(13, p[1]));
      });
    }
    return pos;
  }

  function renderGraph(nodes, edges, opts) {
    const o = opts || {};
    const pos = topoLayout(nodes);
    const lines = edges.map(([a, b]) => {
      const p1 = pos[a], p2 = pos[b];
      if (!p1 || !p2) return '';
      return `<line x1="${p1[0]}%" y1="${p1[1]}%" x2="${p2[0]}%" y2="${p2[1]}%" stroke="#d9e1ec" stroke-width="1" marker-end="url(#arrow)"/>`;
    }).join('');
    const items = nodes.map((n) => {
      const p = pos[n.id];
      const active = o.selected === n.id;
      return `<div class="topo-node ${active ? 'on' : ''}" style="left:${p[0]}%;top:${p[1]}%" data-action="topo-node" data-id="${n.id}">
        <div class="topo-node__circle" style="background:${TYPE_COLOR[n.type] || '#94a3b8'}">${(TYPE_LABEL[n.type] || '节')[0]}</div>
        <div class="topo-node__label">${esc(n.name)}</div></div>`;
    }).join('');
    return `<div class="topo-canvas">
      <svg width="100%" height="100%" style="position:absolute;inset:0"><defs>
        <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
        <path d="M0 0L10 5L0 10z" fill="#c3cede"/></marker></defs>${lines}</svg>
      ${items}<div class="topo-zoom"><button data-action="noop">+</button><button data-action="noop">−</button></div></div>`;
  }

  function pageTopology() {
    const t0 = D.topology;
    const nodes = t0.nodes, edges = t0.edges;
    const counts = Object.keys(TYPE_LABEL).map((k) => [k, nodes.filter((n) => n.type === k).length]).filter((x) => x[1]);
    return `<div class="page-header"><div><h1>智能体拓扑图</h1>
        <p>展示智能体调用依赖（技能 / 模型 / MCP / 智能体 / 第三依赖）；筛选条件满足时在图中高亮节点</p></div></div>
      <section class="card"><div class="topo-wrap">
        <div class="filter-bar" style="border:none;padding:0 0 10px">
          <input class="input" placeholder="搜索节点名称" data-filter="topology.keyword">
          <select class="select"><option>智能体名称</option>${nodes.filter((n) => n.type === 'agent').map((n) => `<option>${esc(n.name)}</option>`).join('')}</select>
          <span class="filter-spacer"></span>
          <button class="btn" data-action="noop">${icon('refresh', 14)} 重置布局</button>
          <button class="btn" data-action="noop">下载</button>
        </div>
        <div class="topo-legend">
          ${counts.map(([k, c]) => `<span class="legend-item"><i class="dot" style="background:${TYPE_COLOR[k]}"></i>${TYPE_LABEL[k]} ${c}</span>`).join('')}
          <span style="color:var(--text-mute)">· ${edges.length} 条调用关系</span>
          <span style="margin-left:auto;color:var(--text-mute)">悬停查看关联调用，拖拽节点调整布局</span>
        </div>
        ${renderGraph(nodes, edges, { selected: state.selectedNode })}
      </div></section>`;
  }

  function pageWorkflowGlobal() {
    const nodes = [], edges = [];
    D.workflows.forEach((wf) => {
      nodes.push({ id: wf.id, name: wf.workflowName, type: 'workflow' });
      wf.agentIds.forEach((aid) => {
        const a = D.agents.find((x) => x.id === aid);
        if (a && !nodes.some((n) => n.id === a.id)) nodes.push({ id: a.id, name: a.name, type: 'agent' });
        edges.push([wf.id, aid]);
      });
    });
    return `<div class="page-header"><div><h1>流程全局视图</h1>
        <p>展示流程与智能体的全局关联：筛选条件满足时在图中高亮节点与关系</p></div></div>
      <section class="card"><div class="topo-wrap">
        <div class="filter-bar" style="border:none;padding:0 0 10px">
          <input class="input" placeholder="搜索智能体名称" data-filter="workflowGlobal.keyword">
          <select class="select"><option>选择流程</option>${D.workflows.map((w) => `<option>${esc(w.workflowName)}</option>`).join('')}</select>
          <span class="filter-spacer"></span>
          <span style="font-size:12px;color:var(--text-mute)">悬停节点可查看详情</span>
        </div>
        <div class="topo-legend">
          <span class="legend-item"><i class="dot" style="background:${TYPE_COLOR.agent}"></i>智能体 ${nodes.filter((n) => n.type === 'agent').length}</span>
          <span class="legend-item"><i class="dot" style="background:${TYPE_COLOR.workflow}"></i>流程 ${nodes.filter((n) => n.type === 'workflow').length}</span>
          <span style="color:var(--text-mute)">· 关联 ${edges.length}</span>
        </div>
        ${renderGraph(nodes, edges, { selected: state.selectedNode })}
      </div></section>`;
  }

  /* ------------------------------ 规划流程：状态模型与度量 ------------------------------ */
  const AGENT_STATUS = {
    LIVE: ['chip--green', '已上线'], WIP: ['chip--cyan', '进行中'], SCHEDULED: ['chip--purple', '已排期'],
    PLANNED: ['chip--orange', '待实施'], DEPRECATED: ['chip--grey', '已废弃'],
  };
  const AGENT_STATUS_WEIGHT = { LIVE: 100, WIP: 60, SCHEDULED: 35, PLANNED: 10, DEPRECATED: 0 };
  const STATUS_COLOR = { LIVE: '#16a34a', WIP: '#0891b2', SCHEDULED: '#7c3aed', PLANNED: '#f59e0b', DEPRECATED: '#94a3b8' };
  const agentChip = (s) => chip((AGENT_STATUS[s] || ['chip--grey', s])[0], (AGENT_STATUS[s] || ['', s])[1]);
  const goalOf = (wf) => D.planGoals.find((g) => g.id === wf.goalId) || {};
  const savingHours = (wf) => Number(String(wf.value.saving).replace(/[^\d]/g, '')) || 0;
  // 可实施度 = 流程内各智能体成熟度的加权均值（已上线 100 / 进行中 60 / 已排期 35 / 待实施 10）
  const planReadiness = (wf) => {
    const list = wf.planAgents || [];
    if (!list.length) return 0;
    return Math.round(list.reduce((a, b) => a + (AGENT_STATUS_WEIGHT[b.status] ?? 0), 0) / list.length);
  };
  const planBlockers = (wf) => (wf.planAgents || []).filter((a) => a.status === 'PLANNED' || a.status === 'DEPRECATED');
  const readinessTone = (v) => (v >= 80 ? 'green' : v >= 50 ? 'orange' : 'red');
  const readinessColor = (v) => (v >= 80 ? '#16a34a' : v >= 50 ? '#f59e0b' : '#dc2626');
  const planStatusChip = (s) => ({ DRAFT: chip('chip--grey', '草稿'), PUBLISHED: chip('chip--green', '已发布'), REVIEWING: chip('chip--orange', '评审中'), REJECTED: chip('chip--red', '已驳回') }[s] || chip('chip--grey', s));
  const INTAKE_TYPE = { Demand: ['chip--blue', '需求'], 'Product idea': ['chip--purple', '产品构想'], Feedback: ['chip--cyan', '反馈'] };
  const INTAKE_STATUS = { 待评审: 'chip--orange', 已分流: 'chip--cyan', 已转流程: 'chip--green', 已驳回: 'chip--red' };

  const allPlanAgents = () => D.workflows.flatMap((wf) => (wf.planAgents || []).map((a) => ({ ...a, workflow: wf })));
  const avgReadiness = () => Math.round(D.workflows.reduce((a, w) => a + planReadiness(w), 0) / Math.max(1, D.workflows.length));

  /* ------------------------------ 页面：规划总览 ------------------------------ */
  function pagePlanOverview() {
    const wfs = D.workflows;
    const agents = allPlanAgents();
    const pending = agents.filter((a) => a.status === 'PLANNED').length;
    const saving = wfs.reduce((a, w) => a + savingHours(w), 0);
    const intakePending = D.planIntake.filter((x) => x.status === '待评审').length;
    const metrics = [
      ['规划流程数', wfs.length, 'blue', 'flow'],
      ['平均可实施度', `${avgReadiness()}%`, 'green', 'value'],
      ['涉及智能体', agents.length, 'cyan', 'users'],
      ['待实施智能体', pending, 'orange', 'approval'],
      ['预计年化节省', `${saving.toLocaleString()} h`, 'purple', 'kpi'],
      ['需求池待评审', intakePending, 'red', 'inbox'],
    ];
    const stageCount = [D.planGoals.length, D.planIntake.length, agents.length];
    const stages = [
      ['战略规划', 'Strategize AI plan', 'AI steward 看组织 AI 战略方向：Goals、Targets、Strategic Priorities 集中维护，把组织目标连到 AI 系统与投资决策。', ['编辑 goal / target / strategic priority 记录', '把目标下挂到业务流程规划'], 'flag'],
      ['需求入口', 'Prioritize AI plan intake', '审阅与分流 incoming AI 需求：Demand / Product idea / Feedback 三类 intake 记录，全表单新建与管理。', ['按优先级与期望价值分流为流程规划', '驳回/归档的需求保留追溯'], 'inbox'],
      ['交付执行', 'Monitor AI Plan execution', '按智能体交付状态监控流程规划的落地进度：已上线 / 进行中 / 已排期 / 待实施，并回算流程可实施度。', ['在流程规划中直接查看智能体状态', '阻塞项自动汇总到规划阻塞清单'], 'flowGlobal'],
    ];
    const statusCounts = Object.keys(AGENT_STATUS).map((k) => ({
      key: k, name: AGENT_STATUS[k][1], count: agents.filter((a) => a.status === k).length,
    })).filter((x) => x.count);
    const ranks = wfs.map((w) => ({ name: w.workflowName, readiness: planReadiness(w), score: w.value.score, id: w.id }))
      .sort((a, b) => b.readiness - a.readiness);
    const blockers = agents.filter((a) => a.status === 'PLANNED' || a.status === 'DEPRECATED');

    return `<div class="page-header"><div><div class="eyebrow">规划流程 · 增强</div><h1>规划总览</h1>
        <p>业务提前规划：战略目标 → 需求入口 → 交付执行，一条线串起来；依赖 Strategic Planning 4.14.0</p></div>
      <div class="page-header__actions">
        <button class="btn" data-action="refresh">${icon('refresh', 14)} ${t('刷新')}</button>
        <button class="btn btn-primary" data-action="workflow-create">${icon('plus', 14)} 新建流程规划</button></div></div>

      <section class="stage-flow">
        ${stages.map(([cn, en, desc, bullets, ic], i) => `
          ${i ? '<div class="stage-arrow">→</div>' : ''}
          <article class="card stage-card">
            <div class="stage-card__head"><span class="metric__icon tone-${['blue', 'cyan', 'green'][i]}">${icon(ic, 17)}</span>
              <div><strong>${cn}</strong><span class="stage-card__en">${en}</span></div>
              <span class="chip chip--blue" style="margin-left:auto">${stageCount[i]} 项</span></div>
            <p>${desc}</p>
            <ul>${bullets.map((b) => `<li>${b}</li>`).join('')}</ul>
          </article>`).join('')}
      </section>

      <section class="metric-grid">${metrics.map(([label, value, tone, ic]) => `
        <article class="card metric"><span class="metric__icon tone-${tone}">${icon(ic, 18)}</span>
        <div><div class="metric__label">${esc(label)}</div><div class="metric__value">${value}</div></div></article>`).join('')}</section>

      <section class="grid-2">
        <article class="card"><div class="card-head"><h2>战略目标与投资</h2><p>Goals / Targets / Strategic Priorities · 共 ${D.planGoals.length} 项</p></div>
          <div class="card-body"><div class="bars">
            ${D.planGoals.map((g) => `<div class="bar-row" style="grid-template-columns:150px 1fr 160px">
              <span><strong style="font-size:13px">${esc(g.name)}</strong><br><small style="color:var(--text-mute)">${esc(g.form)} · ${esc(g.priority)}</small></span>
              <span class="bar-track"><i class="bar-fill" style="display:block;width:${g.progress}%;background:#2563eb"></i></span>
              <span style="font-size:12px;color:var(--text-sub);white-space:nowrap">${esc(g.current)} / ${esc(g.target)}</span></div>`).join('')}
          </div>
          <div class="hint" style="color:var(--text-mute);font-size:12px;margin-top:10px">投入合计 4,540 人日 · 关联 ${wfs.length} 个流程规划</div></div></article>

        <article class="card"><div class="card-head"><h2>智能体交付状态分布</h2><p>规划流程内涉及的 ${agents.length} 个智能体当前状态</p></div>
          <div class="card-body">${hbars(statusCounts.map((s) => ({ name: s.name, count: s.count, key: s.key })), (it) => STATUS_COLOR[it.key] || '#2563eb')}
            <div class="legend" style="flex-direction:row;flex-wrap:wrap;gap:14px;margin-top:12px">
              ${statusCounts.map((s) => `<span><i style="background:${STATUS_COLOR[s.key]}"></i>${s.name} ${s.count}</span>`).join('')}</div>
          </div></article>
      </section>

      <section class="grid-2" style="margin-top:16px">
        <article class="card"><div class="card-head"><h2>流程规划可实施度排名</h2><p>由流程内智能体成熟度加权计算，括号内为业务价值评分</p></div>
          <div class="card-body"><div class="bars">
            ${ranks.map((r) => `<div class="bar-row" style="grid-template-columns:150px 1fr 116px">
              <span style="font-size:13px">${esc(r.name)}</span>
              <span class="bar-track"><i class="bar-fill" style="display:block;width:${r.readiness}%;background:${readinessColor(r.readiness)}"></i></span>
              <strong>${r.readiness}% <small style="color:var(--text-mute);font-weight:400">(价值 ${r.score})</small></strong></div>`).join('')}
          </div></div></article>

        <article class="card"><div class="card-head"><h2>规划阻塞项</h2><p>处于“待实施 / 已废弃”的智能体，共 ${blockers.length} 项</p></div>
          <div class="card-body">
            ${blockers.length ? blockers.map((b) => `<div style="display:flex;gap:12px;align-items:flex-start;padding:10px 0;border-bottom:1px solid var(--line-soft)">
              <span class="chip chip--orange" style="flex:none"><i class="dot"></i>待实施</span>
              <div><div style="font-weight:600">${esc(b.name)}</div>
                <div style="font-size:12px;color:var(--text-sub)">所属流程：${esc(b.workflow.workflowName)} · 依赖：${esc(b.dependency)}</div>
                ${b.note ? `<div style="font-size:12px;color:var(--text-mute)">${esc(b.note)}</div>` : ''}</div>
              <button class="btn btn-sm" style="margin-left:auto" data-action="plan-detail" data-id="${b.workflow.id}">查看流程</button>
            </div>`).join('') : '<div class="empty">暂无阻塞项</div>'}
          </div></article>
      </section>

      <section class="card" style="margin-top:16px">
        <div class="card-head"><h2>Reference（表单字段）<span class="stage-card__en">表单参考</span></h2>
          <p>Demand / Epic / Feedback / Goal / Project / Product idea / Strategic Priority / Target 八张表单的字段说明</p></div>
        <div class="card-body"><div class="form-ref">
          ${D.planForms.map((f) => `<article class="form-ref__item">
            <div><strong>${esc(f.name)}</strong><span class="tag-plain" style="margin-left:6px">${esc(f.cn)}</span>
              <span style="float:right;color:var(--text-mute);font-size:12px">${f.fields} 字段</span></div>
            <p>${esc(f.desc)}</p></article>`).join('')}
        </div></div>
      </section>`;
  }

  /* ------------------------------ 页面：流程规划 ------------------------------ */
  function pagePlanWorkflows() {
    const f = state.filters.plan || {};
    const rows = D.workflows.filter((w) => {
      const kw = (f.keyword || '').trim().toLowerCase();
      if (kw && !(w.workflowName + w.workflowCode + w.owner).toLowerCase().includes(kw)) return false;
      if (f.goalId && w.goalId !== f.goalId) return false;
      if (f.priority && w.priority !== f.priority) return false;
      if (f.status && w.status !== f.status) return false;
      const r = planReadiness(w);
      if (f.readiness === 'high' && r < 80) return false;
      if (f.readiness === 'mid' && (r < 50 || r >= 80)) return false;
      if (f.readiness === 'low' && r >= 50) return false;
      return true;
    });
    const ready = D.workflows.filter((w) => planReadiness(w) >= 80).length;
    const blocked = D.workflows.filter((w) => planBlockers(w).length).length;
    const metrics = [
      ['流程规划数', D.workflows.length, 'blue', 'flow'],
      ['平均可实施度', `${avgReadiness()}%`, 'green', 'value'],
      ['可立即实施（≥80%）', ready, 'cyan', 'check'],
      ['存在阻塞项', blocked, 'orange', 'approval'],
    ];
    return `<div class="banner">规划流程：新建业务流程时提前盘点涉及的智能体及其交付状态，系统自动回算流程可实施度与规划价值，作为排期与投资决策依据。</div>
      <div class="page-header"><div><h1>流程规划</h1>
        <p>维护跨智能体协作流程定义，并按智能体状态评估可实施度（新建 / 编辑 / 删除 / 规划详情）</p></div>
      <div class="page-header__actions">
        <button class="btn" data-action="refresh">${icon('refresh', 14)} ${t('刷新')}</button>
        <button class="btn btn-primary" data-action="workflow-create">${icon('plus', 14)} 新建流程规划</button></div></div>

      <section class="metric-grid">${metrics.map(([label, value, tone, ic]) => `
        <article class="card metric"><span class="metric__icon tone-${tone}">${icon(ic, 18)}</span>
        <div><div class="metric__label">${esc(label)}</div><div class="metric__value">${value}</div></div></article>`).join('')}</section>

      <section class="card">
        <div class="filter-bar">
          <input class="input" placeholder="搜索流程名称 / 编码 / 负责人" value="${esc(f.keyword || '')}" data-filter="plan.keyword">
          <select class="select" data-filter="plan.goalId"><option value="">战略目标</option>
            ${D.planGoals.map((g) => `<option value="${g.id}" ${f.goalId === g.id ? 'selected' : ''}>${esc(g.name)}</option>`).join('')}</select>
          <select class="select" data-filter="plan.priority"><option value="">优先级</option>
            ${['P0', 'P1', 'P2'].map((p) => `<option value="${p}" ${f.priority === p ? 'selected' : ''}>${p}</option>`).join('')}</select>
          <select class="select" data-filter="plan.readiness"><option value="">可实施度</option>
            <option value="high" ${f.readiness === 'high' ? 'selected' : ''}>≥ 80% 可实施</option>
            <option value="mid" ${f.readiness === 'mid' ? 'selected' : ''}>50% - 79% 推进中</option>
            <option value="low" ${f.readiness === 'low' ? 'selected' : ''}>&lt; 50% 有阻塞</option></select>
          <span class="filter-spacer"></span>
          <button class="btn" data-action="reset-filter" data-scope="plan">${icon('refresh', 14)} ${t('重置')}</button></div>

        <div style="overflow:auto"><table class="data"><thead><tr>
          <th>流程规划</th><th>战略目标</th><th>涉及智能体</th><th>智能体状态</th><th style="width:170px">可实施度</th>
          <th>规划价值</th><th>优先级</th><th>期望上线</th><th>操作</th></tr></thead>
        <tbody>${rows.length ? rows.map((w) => {
          const g = goalOf(w);
          const r = planReadiness(w);
          const counts = Object.keys(AGENT_STATUS).map((k) => [k, (w.planAgents || []).filter((a) => a.status === k).length]).filter((x) => x[1]);
          return `<tr>
            <td><div class="cell-name"><span class="avatar-sq" style="background:${readinessColor(r)}">${icon('flow', 15)}</span>
              <div><div>${esc(w.workflowName)}</div><small>${esc(w.workflowCode)} · v${w.revision}</small></div></div></td>
            <td><div style="font-size:13px">${esc(g.name || '—')}</div><small style="color:var(--text-mute)">${esc(g.form || '')}</small></td>
            <td><span class="chip chip--purple">${(w.planAgents || []).length} 个</span></td>
            <td><div style="display:flex;flex-wrap:wrap;gap:4px;max-width:210px">
              ${counts.map(([k, n]) => `<span class="chip ${AGENT_STATUS[k][0]}" title="${AGENT_STATUS[k][1]}">${AGENT_STATUS[k][1]} ${n}</span>`).join('')}</div></td>
            <td><div style="display:flex;align-items:center;gap:10px">
              <span class="bar-track" style="flex:1"><i class="bar-fill" style="display:block;width:${r}%;background:${readinessColor(r)}"></i></span>
              <strong style="color:${readinessColor(r)}">${r}%</strong></div>
              ${planBlockers(w).length ? `<small style="color:#b8730a">${planBlockers(w).length} 项待实施</small>` : ''}</td>
            <td><div style="font-size:13px">${esc(w.value.saving)}</div><small style="color:var(--text-mute)">覆盖 ${esc(w.value.coverage)} · ROI ${esc(w.value.roi)}</small></td>
            <td>${chip(w.priority === 'P0' ? 'chip--red' : w.priority === 'P1' ? 'chip--orange' : 'chip--grey', w.priority)}</td>
            <td>${esc(w.expectedOnline)}</td>
            <td><div class="row-actions">
              <button class="btn btn-sm btn-primary" data-action="plan-detail" data-id="${w.id}">规划详情</button>
              <button class="btn btn-sm" data-action="workflow-edit" data-id="${w.id}">✎ ${t('编辑')}</button>
              <button class="btn btn-sm btn-danger" data-action="workflow-delete" data-id="${w.id}">${icon('trash', 12)}</button>
            </div></td></tr>`;
        }).join('') : '<tr><td colspan="9"><div class="empty">暂无流程规划数据</div></td></tr>'}</tbody></table></div>
        <div class="table-foot"><span>共 ${rows.length} 条</span><div class="pager"><button class="on">1</button></div></div>
      </section>`;
  }

  /* ------------------------------ 页面：需求入口 ------------------------------ */
  function pagePlanIntake() {
    const f = state.filters.intake || {};
    const tab = state.intakeTab || 'all';
    const rows = D.planIntake.filter((x) => {
      if (tab !== 'all' && x.type !== tab) return false;
      const kw = (f.keyword || '').trim().toLowerCase();
      if (kw && !(x.title + x.id + x.source).toLowerCase().includes(kw)) return false;
      if (f.status && x.status !== f.status) return false;
      return true;
    });
    const metrics = [
      ['需求池总数', D.planIntake.length, 'blue', 'inbox'],
      ['待评审', D.planIntake.filter((x) => x.status === '待评审').length, 'orange', 'approval'],
      ['已转流程规划', D.planIntake.filter((x) => x.status === '已转流程').length, 'green', 'check'],
      ['已驳回', D.planIntake.filter((x) => x.status === '已驳回').length, 'red', 'close'],
    ];
    const tabs = [['all', '全部'], ['Demand', 'Demand 需求'], ['Product idea', 'Product idea 产品构想'], ['Feedback', 'Feedback 反馈']];
    return `<div class="banner">需求入口：审阅与分流 incoming AI 需求（Demand / Product idea / Feedback），评审通过后分流为流程规划并纳入可实施度评估。</div>
      <div class="page-header"><div><h1>需求入口</h1>
        <p>集中管理 AI 需求来源，按优先级与期望价值分流到流程规划</p></div>
      <div class="page-header__actions">
        <button class="btn" data-action="refresh">${icon('refresh', 14)} ${t('刷新')}</button>
        <button class="btn btn-primary" data-action="intake-create">${icon('plus', 14)} 新建需求</button></div></div>

      <section class="metric-grid">${metrics.map(([label, value, tone, ic]) => `
        <article class="card metric"><span class="metric__icon tone-${tone}">${icon(ic, 18)}</span>
        <div><div class="metric__label">${esc(label)}</div><div class="metric__value">${value}</div></div></article>`).join('')}</section>

      <section class="card">
        <div class="tabs" style="padding:0 18px">${tabs.map(([k, label]) => `<button class="${tab === k ? 'on' : ''}" data-action="intake-tab" data-value="${k}">${label}</button>`).join('')}</div>
        <div class="filter-bar" style="border-top:1px solid var(--line-soft)">
          <input class="input" placeholder="搜索需求标题 / 编号 / 来源" value="${esc(f.keyword || '')}" data-filter="intake.keyword">
          <select class="select" data-filter="intake.status"><option value="">全部状态</option>
            ${Object.keys(INTAKE_STATUS).map((s) => `<option value="${s}" ${f.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select>
          <span class="filter-spacer"></span>
          <button class="btn" data-action="reset-filter" data-scope="intake">${icon('refresh', 14)} ${t('重置')}</button></div>
        <div style="overflow:auto"><table class="data"><thead><tr>
          <th>需求</th><th>类型</th><th>来源</th><th>期望价值</th><th>归属战略目标</th><th>关联流程</th><th>负责人</th><th>状态</th><th>提交时间</th><th>操作</th></tr></thead>
        <tbody>${rows.length ? rows.map((x) => {
          const g = D.planGoals.find((y) => y.id === x.goalId) || {};
          const wf = D.workflows.find((y) => y.id === x.relatedWorkflow);
          return `<tr>
            <td><div style="font-weight:600">${esc(x.title)}</div><small style="color:var(--text-mute)">${esc(x.id)}</small></td>
            <td>${chip(INTAKE_TYPE[x.type][0], INTAKE_TYPE[x.type][1])}</td>
            <td>${esc(x.source)}</td><td>${esc(x.expectedValue)}</td>
            <td>${esc(g.name || '—')}</td><td>${esc(wf ? wf.workflowName : '—')}</td><td>${esc(x.owner)}</td>
            <td>${chip(INTAKE_STATUS[x.status], x.status)}</td><td>${esc(x.submittedAt)}</td>
            <td><div class="row-actions">
              <button class="btn btn-sm" data-action="intake-detail" data-id="${x.id}">详情</button>
              ${x.status === '待评审' || x.status === '已分流'
                ? `<button class="btn btn-sm btn-primary" data-action="intake-convert" data-id="${x.id}">转为流程规划</button>` : ''}
            </div></td></tr>`;
        }).join('') : '<tr><td colspan="10"><div class="empty">暂无需求记录</div></td></tr>'}</tbody></table></div>
        <div class="table-foot"><span>共 ${rows.length} 条</span><div class="pager"><button class="on">1</button></div></div>
      </section>`;
  }

  /* ------------------------------ 页面：知识库 ------------------------------ */
  function pageKnowledgeBases() {
    const f = state.filters.kb || {};
    const rows = D.knowledgeBases.filter((k) => {
      const kw = (f.keyword || '').trim().toLowerCase();
      if (kw && !k.name.toLowerCase().includes(kw)) return false;
      if (f.status !== undefined && f.status !== '' && String(k.status) !== String(f.status)) return false;
      return true;
    });
    return `<div class="page-header"><div><h1>知识库列表</h1><p>展示当前空间内所有知识库（共 ${D.knowledgeBases.length} 个）</p></div>
      <div class="page-header__actions"><button class="btn" data-action="refresh">${icon('refresh', 14)} ${t('刷新')}</button>
        <button class="btn btn-primary" data-action="kb-create">${icon('plus', 14)} ${t('新增')}</button></div></div>
      <section class="card">
        <div class="filter-bar">
          <input class="input" placeholder="搜索知识库名称" value="${esc(f.keyword || '')}" data-filter="kb.keyword">
          <select class="select" data-filter="kb.status"><option value="">启用状态</option>
            <option value="1" ${String(f.status) === '1' ? 'selected' : ''}>启用</option>
            <option value="0" ${String(f.status) === '0' ? 'selected' : ''}>禁用</option></select>
          <span class="filter-spacer"></span>
          <button class="btn" data-action="reset-filter" data-scope="kb">${icon('refresh', 14)} ${t('重置')}</button></div>
        <table class="data"><thead><tr><th>知识库名称</th><th>租户工作空间编码</th><th>知识库类型</th><th>启用状态</th><th>创建人</th><th>更新人</th><th>操作</th></tr></thead>
        <tbody>${rows.map((k) => `<tr>
          <td><div><div style="font-weight:600">${esc(k.name)}</div><small style="color:var(--text-mute)">${esc(k.knowledgeId)}</small></div></td>
          <td><span class="tag-plain">${esc(k.wsCode)}</span></td>
          <td>${chip('chip--blue', k.type === 'VECTOR' ? '向量库' : 'RAG')}</td>
          <td>${k.status ? chip('chip--green', '启用') : chip('chip--grey', '禁用')}</td>
          <td>${esc(k.createdBy)}</td><td>${esc(k.updatedBy)}</td>
          <td><div class="row-actions">
            <button class="btn btn-sm" data-action="kb-edit" data-id="${k.id}">✎</button>
            <button class="btn btn-sm btn-danger" data-action="kb-delete" data-id="${k.id}">${icon('trash', 12)}</button></div></td></tr>`).join('')}
        </tbody></table>
        <div class="table-foot"><span>共 ${rows.length} 条</span><div class="pager"><button class="on">1</button></div></div>
      </section>`;
  }

  /* ------------------------------ 页面：KPI ------------------------------ */
  function pageAgentKpi() {
    const m = D.kpiMetrics;
    const onTrack = m.filter((x) => x.status === 'onTrack').length;
    const alert = m.filter((x) => x.status === 'alert').length;
    const off = m.filter((x) => x.status === 'offTrack').length;
    const statusChipOf = (s) => ({ onTrack: chip('chip--green', '进展正常'), alert: chip('chip--orange', '预警'), offTrack: chip('chip--red', '偏离目标') }[s]);
    const cats = [['technical', '技术表现', '质量、可靠性与运行效率', 'blue'], ['adoption', '采用指标', '人机协作的覆盖范围、参与度与深度', 'cyan'], ['operational', '运营 KPI', '业务成果与可量化的效率提升', 'orange']];
    return `<div class="page-header"><div><div class="eyebrow">观测洞察</div><h1>智能体 KPI 仪表盘</h1>
        <p>监控智能体质量、采用情况与运营成效。</p></div>
      <div class="page-header__actions">
        <span class="topbar__label">Agent</span><select class="select" style="width:180px">${D.agents.map((a) => `<option>${esc(a.name)}</option>`).join('')}</select>
        <select class="select" style="width:120px"><option>近 30 天</option><option>近 7 天</option><option>近一季度</option></select>
        <button class="btn" data-action="refresh">${icon('refresh', 14)} ${t('刷新')}</button></div></div>
      <section class="card" style="margin-bottom:16px"><div class="card-body" style="display:flex;align-items:center;gap:30px;flex-wrap:wrap">
        <div style="display:flex;align-items:baseline;gap:8px"><span style="font-size:40px;font-weight:700;color:#0ea5a4">55</span>
          <span style="font-size:18px;color:var(--text-sub)">%</span>
          <div style="margin-left:8px"><div style="font-size:12px;color:var(--text-sub)">KPI 整体健康度</div>
            <strong>${onTrack}/${m.length} 项指标进展正常</strong></div></div>
        <div style="display:flex;gap:26px">${[['进展正常', onTrack, 'green'], ['预警', alert, 'orange'], ['偏离目标', off, 'red']]
          .map(([label, n, tone]) => `<div><span class="chip chip--${tone}"><i class="dot"></i>${label}</span><div style="font-size:22px;font-weight:700;margin-top:6px">${n}</div></div>`).join('')}</div>
        <div style="margin-left:auto;color:var(--text-sub);font-size:12px">最近刷新<br><strong style="color:var(--text)">${stamp(new Date().toISOString())}</strong></div>
      </div></section>
      <section class="grid-2" style="margin-bottom:18px">
        <article class="card"><div class="card-head"><h2>状态分布</h2><p>全部指标的当前健康状态</p></div>
          <div class="card-body">${donut([{ name: '进展正常', count: onTrack }, { name: '预警', count: alert }, { name: '偏离目标', count: off }], ['#16a34a', '#f59e0b', '#dc2626'], 190)}</div></article>
        <article class="card"><div class="card-head"><h2>分类表现</h2><p>各分类相对配置目标的平均达成度</p></div>
          <div class="card-body">
            <div class="bars">${cats.map(([k, name], i) => {
              const list = m.filter((x) => x.category === k);
              const pct = list.length ? Math.round(list.reduce((a, b) => a + b.progress, 0) / list.length) : 0;
              return `<div class="bar-row" style="grid-template-columns:86px 1fr 52px">
                <span>${name}</span>
                <span class="bar-track"><i class="bar-fill" style="display:block;width:${pct}%;background:${['#2563eb', '#0ea5a4', '#f59e0b'][i]}"></i></span>
                <strong>${pct}%</strong></div>`;
            }).join('')}</div>
            <div style="display:flex;justify-content:space-between;color:var(--text-mute);font-size:12px;margin:14px 0 0 96px">
              <span>0%</span><span>目标 80%</span><span>100%</span></div>
          </div></article>
      </section>
      ${cats.map(([k, name, desc]) => {
        const list = m.filter((x) => x.category === k);
        return `<section style="margin-bottom:22px">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
            <strong>${name}</strong><span style="color:var(--text-sub);font-size:12px">${desc}</span>
            <span style="margin-left:auto;color:var(--text-mute);font-size:12px">${list.length} 项指标</span></div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px">
          ${list.map((x) => `<article class="kpi-card">
            <div class="kpi-card__top">${statusChipOf(x.status)}<span style="color:var(--text-mute)">?</span></div>
            <div style="font-size:13px;color:var(--text-sub)">${esc(x.metricName)}</div>
            <div class="kpi-card__value">${esc(x.displayValue)}</div>
            <div class="progress"><i style="width:${x.progress}%;background:${x.status === 'onTrack' ? '#16a34a' : x.status === 'alert' ? '#f59e0b' : '#dc2626'}"></i></div>
            <div class="kpi-card__foot"><span>${esc(x.targetText)}</span><span style="color:${x.delta.startsWith('-') ? '#dc2626' : '#16a34a'}">${esc(x.delta)}</span></div>
            <div class="kpi-card__foot"><span>更新于 ${stamp(new Date().toISOString()).slice(11)}</span></div>
          </article>`).join('')}</div></section>`;
      }).join('')}`;
  }

  function pageKpiMaintenance() {
    const f = state.filters.kpi || {};
    const rows = D.kpiDefinitions.filter((k) => {
      const kw = (f.keyword || '').trim().toLowerCase();
      if (kw && !k.metricName.toLowerCase().includes(kw)) return false;
      if (f.agentId && k.agentId !== f.agentId) return false;
      if (f.category && k.category !== f.category) return false;
      return true;
    });
    const CAT = { technical: '技术表现', adoption: '采用指标', operational: '运营 KPI' };
    const UNIT = { percent: '%', seconds: '秒', hours: '小时', count: '数值' };
    const target = (k) => k.targetType === 'period'
      ? `${k.periodValue}${k.periodUnit === 'month' ? '月' : k.periodUnit === 'week' ? '周' : '天'}内 ${k.targetOperator} ${k.targetValue}${UNIT[k.targetUnit]}`
      : `${k.targetOperator} ${k.targetValue}${UNIT[k.targetUnit]}`;
    return `<div class="page-header"><div><h1>KPI 数据维护</h1><p>为智能体配置指标、计算口径与目标规则。</p></div>
      <div class="page-header__actions"><button class="btn btn-primary" data-action="kpi-create">${icon('plus', 14)} 新增指标</button></div></div>
      <section class="metric-grid" style="grid-template-columns:repeat(3,minmax(0,1fr))">
        ${[['指标总数', D.kpiDefinitions.length], ['单值目标', D.kpiDefinitions.filter((k) => k.targetType === 'scalar').length], ['周期目标', D.kpiDefinitions.filter((k) => k.targetType === 'period').length]]
          .map(([l, v]) => `<article class="card metric"><div><div class="metric__label">${l}</div><div class="metric__value">${v}</div></div></article>`).join('')}</section>
      <section class="card">
        <div class="filter-bar">
          <input class="input" placeholder="搜索指标名称" value="${esc(f.keyword || '')}" data-filter="kpi.keyword">
          <select class="select" data-filter="kpi.agentId"><option value="">全部 Agent</option>
            ${D.agents.map((a) => `<option value="${a.id}" ${f.agentId === a.id ? 'selected' : ''}>${esc(a.name)}</option>`).join('')}</select>
          <select class="select" data-filter="kpi.category"><option value="">全部分类</option>
            ${Object.entries(CAT).map(([k, v]) => `<option value="${k}" ${f.category === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
          <button class="btn" data-action="reset-filter" data-scope="kpi">重置</button></div>
        <table class="data"><thead><tr><th>指标</th><th>Agent</th><th>分类</th><th>目标规则</th><th>状态</th><th>更新时间</th><th>操作</th></tr></thead>
        <tbody>${rows.length ? rows.map((k) => {
          const a = D.agents.find((x) => x.id === k.agentId);
          return `<tr>
            <td><div style="font-weight:600">${esc(k.metricName)}</div><small style="color:var(--text-mute)">${esc(k.calculationLogic.slice(0, 26))}…</small></td>
            <td>${esc(a ? a.name : '—')}</td><td>${chip('chip--blue', CAT[k.category])}</td>
            <td><span class="tag-plain">${esc(target(k))}</span></td>
            <td>${k.enabled ? chip('chip--green', '已启用') : chip('chip--grey', '已停用')}</td>
            <td>${esc(k.updatedAt)}</td>
            <td><div class="row-actions"><button class="btn btn-sm" data-action="kpi-edit" data-id="${k.id}">${t('编辑')}</button>
              <button class="btn btn-sm btn-danger" data-action="kpi-delete" data-id="${k.id}">${t('删除')}</button></div></td></tr>`;
        }).join('') : '<tr><td colspan="7"><div class="empty">暂无 KPI 配置</div></td></tr>'}</tbody></table>
      </section>`;
  }

  /* ------------------------------ 页面：空间管理 / 用户管理 ------------------------------ */
  function pageTenants() {
    const f = state.filters.tenants || {};
    const rows = D.tenants.filter((x) => {
      const kw = (f.keyword || '').trim().toLowerCase();
      if (kw && !(x.wsName + x.wsCode).toLowerCase().includes(kw)) return false;
      if (f.status !== undefined && f.status !== '' && String(x.status) !== String(f.status)) return false;
      return true;
    });
    const stat = [['空间总数', D.tenants.length, 'blue'], ['使用中数', D.tenants.filter((x) => x.status).length, 'green'], ['冻结数', D.tenants.filter((x) => !x.status).length, 'grey']];
    return `<div class="page-header"><div><h1>空间管理</h1>
        <p>平台用户创建并管理空间，维护空间使用状态与访问凭证（仅平台用户可见）</p></div>
      <div class="page-header__actions"><button class="btn btn-primary" data-action="tenant-create">${icon('plus', 14)} ${t('创建空间')}</button>
        <button class="btn" data-action="refresh">${icon('refresh', 14)} ${t('刷新')}</button></div></div>
      <section class="metric-grid" style="grid-template-columns:repeat(3,minmax(0,1fr))">
        ${stat.map(([l, v, tone]) => `<article class="card metric"><span class="metric__icon tone-${tone}">${icon('workspace', 18)}</span>
          <div><div class="metric__label">${l}</div><div class="metric__value">${v}</div></div></article>`).join('')}</section>
      <section class="card">
        <div class="filter-bar">
          <input class="input" style="width:260px" placeholder="搜索空间名称或编码" value="${esc(f.keyword || '')}" data-filter="tenants.keyword">
          <select class="select" data-filter="tenants.status"><option value="">全部状态</option>
            <option value="1" ${String(f.status) === '1' ? 'selected' : ''}>使用中</option>
            <option value="0" ${String(f.status) === '0' ? 'selected' : ''}>冻结</option></select>
          <span class="filter-spacer"></span>
          <button class="btn" data-action="reset-filter" data-scope="tenants">重置</button></div>
        <div style="overflow:auto"><table class="data"><thead><tr>
          <th>空间名称</th><th>空间编码</th><th>创建人</th><th>所属组织</th><th>申请时间</th><th>状态</th><th>空间描述</th><th>操作</th></tr></thead>
        <tbody>${rows.map((x) => `<tr>
          <td style="font-weight:600">${esc(x.wsName)}</td><td>${esc(x.wsCode)}</td><td>${esc(x.ownerId)}</td>
          <td>${esc(x.department)}</td><td>${esc(stamp(x.createdAt))}</td>
          <td>${x.status ? chip('chip--green', '使用中') : chip('chip--grey', '冻结')}</td>
          <td style="max-width:260px">${esc(x.wsDescription)}</td>
          <td><div class="row-actions">
            <button class="btn btn-sm btn-primary" data-action="tenant-edit" data-id="${x.id}">${t('编辑')}</button>
            <button class="btn btn-sm" data-action="tenant-detail" data-id="${x.id}">${t('详情')}</button>
            <button class="btn btn-sm btn-danger" data-action="tenant-toggle" data-id="${x.id}">${x.status ? '禁用' : '启用'}</button>
            <button class="btn btn-sm" data-action="tenant-users" data-id="${x.id}">用户管理</button>
          </div></td></tr>`).join('')}</tbody></table></div>
        <div class="table-foot"><span>共 ${rows.length} 条</span><div class="pager"><button class="on">1</button></div></div>
      </section>`;
  }

  function pageUsers() {
    const f = state.filters.users || {};
    const rows = D.members.filter((u) => {
      const kw = (f.keyword || '').trim().toLowerCase();
      if (kw && !(u.userId + u.email).toLowerCase().includes(kw)) return false;
      return true;
    });
    const roleChip = (r) => ({ sys_admin: chip('chip--red', ROLE_LABEL.sys_admin), ws_admin: chip('chip--blue', ROLE_LABEL.ws_admin), ws_basic: chip('chip--grey', ROLE_LABEL.ws_basic) }[r]);
    return `<div class="page-header"><div><h1>用户管理</h1>
        <p>管理平台 / 租户内用户（ADFS 身份映射、角色、启用状态）</p></div>
      <div class="page-header__actions">
        <input class="input" style="width:220px" placeholder="搜索 ItCode / 邮箱" value="${esc(f.keyword || '')}" data-filter="users.keyword">
        <button class="btn btn-primary" data-action="user-create">${icon('plus', 14)} ${t('添加用户')}</button></div></div>
      <section class="card"><table class="data"><thead><tr>
        <th>用户</th><th>角色</th><th>所属空间</th><th>状态</th><th>来源</th><th>操作</th></tr></thead>
      <tbody>${rows.map((u) => `<tr>
        <td><div class="cell-name"><span class="avatar-sq" style="background:${avatarColor(u.userName)}">${esc(u.userName.slice(0, 1))}</span>
          <div><div>${esc(u.userName)}</div><small>${esc(u.email)}</small></div></div></td>
        <td>${roleChip(u.role)}</td><td>${esc(u.wsName)}</td>
        <td>${u.status ? chip('chip--green', '启用') : chip('chip--grey', '禁用')}</td>
        <td><span class="tag-plain">ADFS</span></td>
        <td><div class="row-actions">
          <button class="btn btn-sm" data-action="user-edit" data-id="${u.id}">${t('编辑')}</button>
          <button class="btn btn-sm" data-action="user-toggle" data-id="${u.id}">${u.status ? '禁用' : '启用'}</button>
          <button class="btn btn-sm btn-danger" data-action="user-remove" data-id="${u.id}">移除</button></div></td></tr>`).join('')}
      </tbody></table>
      <div class="table-foot"><span>共 ${rows.length} 条</span><div class="pager"><button class="on">1</button></div></div></section>`;
  }

  /* ------------------------------ 占位页 ------------------------------ */
  function pagePlaceholder(key) {
    const title = (ROUTE_TITLES[key] || ['', '页面'])[1];
    return `<div class="page-header"><div><h1>${esc(title)}</h1><p>该模块在现网 SIT 环境尚未接入页面组件。</p></div></div>
      <section class="card"><div class="placeholder-note">
        <strong>${esc(title)} · 功能建设中</strong>
        原型访问 control-plane-sit 环境时，该路由挂载的是空占位组件（PlaceholderView），
        因此本原型保持一致：仅保留导航入口与权限可见性，不呈现具体内容。<br><br>
        建议后续迭代补充：能力清单、上下架状态、调用统计与审批流。
      </div></section>`;
  }

  /* ------------------------------ 视图分发 ------------------------------ */
  function renderView() {
    if (state.route.startsWith('collab-')) return window.ACP_COLLAB.render(state.route, {role:currentRole(), ws:state.wsCode}, render, navigate, toast);
    if (state.route.startsWith('policy-')) return window.ACP_POLICY.render(state.route, {role:currentRole(), ws:state.wsCode}, render, navigate, toast);
    switch (state.route) {
      case 'overview': return pageOverview();
      case 'system-dashboard': return pageSystemDashboard();
      case 'agent-list': return pageAgentList();
      case 'agent-register': return pageAgentRegister();
      case 'agent-approval': return pageAgentApproval();
      case 'agent-topology': return pageTopology();
      case 'plan-overview': return pagePlanOverview();
      case 'plan-workflows': return pagePlanWorkflows();
      case 'plan-intake': return pagePlanIntake();
      case 'workflow-global': return pageWorkflowGlobal();
      case 'knowledge-bases': return pageKnowledgeBases();
      case 'agent-kpi': return pageAgentKpi();
      case 'kpi-maintenance': return pageKpiMaintenance();
      case 'settings-tenants': return pageTenants();
      case 'settings-users': return pageUsers();
      default: return pagePlaceholder(state.route);
    }
  }

  /* ------------------------------ 覆盖层（抽屉 / 弹窗） ------------------------------ */
  function renderOverlay() {
    const o = state.overlay;
    if (!o) return '';
    if (o.key === 'agent-detail') {
      const a = D.agents.find((x) => x.id === o.data);
      if (!a) return '';
      return overlayModal('智能体详情', `
        <div class="tabs" style="padding:0 0 12px"><button class="on">基本信息</button><button>能力与技能</button></div>
        <div class="form-grid" style="padding:0">
          <div class="field"><label>智能体标识</label><input class="input" value="${esc(a.agentCode)}"></div>
          <div class="field"><label>名称</label><input class="input" value="${esc(a.name)}"></div>
          <div class="field"><label>展示名称</label><input class="input" value="${esc(a.displayName)}"></div>
          <div class="field"><label>版本</label><input class="input" value="${esc(a.version)}"></div>
          <div class="field"><label>所属部门</label><input class="input" value="${esc(a.department)}"></div>
          <div class="field"><label>业务分类</label><input class="input" value="${esc(a.category)}"></div>
          <div class="field"><label>负责人</label><input class="input" value="${esc(a.owner)}"></div>
          <div class="field"><label>负责人邮箱</label><input class="input" value="${esc(a.ownerEmail)}"></div>
          <div class="field"><label>网关类型</label><input class="input" value="${esc(a.type)}"></div>
          <div class="field"><label>数据中心</label><input class="input" value="${esc(a.dataCenter)}"></div>
          <div class="field"><label>规划状态</label><input class="input" value="${esc(PLAN_CHIP[a.planStatus][1])}"></div>
          <div class="field"><label>审核状态</label><input class="input" value="${esc(AUDIT_CHIP[a.auditStatus][1])}"></div>
          <div class="field full"><label>能力描述</label><textarea class="textarea">${esc(a.description)}</textarea></div>
        </div>`, { wide: true, foot: `<button class="btn" data-action="close-overlay">取消</button><button class="btn btn-primary" data-action="save">保存</button>` });
    }
    if (o.key === 'agent-history') {
      const a = D.agents.find((x) => x.id === o.data);
      return overlayDrawer('智能体版本', `
        <p style="margin-top:0;color:var(--text-sub);font-size:13px">${esc(a ? a.name : '')} · 变更需空间管理员审批后生效</p>
        <table class="data"><thead><tr><th>版本号</th><th>操作人</th><th>更新时间</th><th>操作</th></tr></thead><tbody>
          <tr><td>v${esc(a ? a.version : '')}</td><td>王敏</td><td>${stamp(new Date().toISOString())}</td>
            <td><div class="row-actions"><span class="chip chip--orange"><i class="dot"></i>待审批</span>
              <button class="btn btn-sm btn-primary" data-action="version-approve">通过</button>
              <button class="btn btn-sm btn-danger" data-action="version-reject">驳回</button></div></td></tr>
          <tr><td>v1.4.1</td><td>王敏</td><td>2026-09-18 15:40</td><td>${chip('chip--green', '已通过')}</td></tr>
          <tr><td>v1.4.0</td><td>李强</td><td>2026-09-02 09:12</td><td>${chip('chip--green', '已通过')}</td></tr>
        </tbody></table>`, { narrow: true, foot: '' });
    }
    if (o.key === 'topo-node') {
      const n = D.topology.nodes.find((x) => x.id === o.data) || {};
      return overlayDrawer('节点详情', `
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
          <span class="avatar-sq" style="width:38px;height:38px;background:${TYPE_COLOR[n.type] || '#94a3b8'}">${(TYPE_LABEL[n.type] || '节')[0]}</span>
          <div><div style="font-size:16px;font-weight:600">${esc(n.name || '')}</div>
          <div style="font-size:12px;color:var(--text-mute)">${TYPE_LABEL[n.type] || ''} · ${esc(n.id || '')}</div></div></div>
        <dl class="kv">
          <dt>节点类型</dt><dd>${TYPE_LABEL[n.type] || '—'}</dd>
          <dt>描述</dt><dd>${esc(n.description || '暂无描述')}</dd>
          ${n.department ? `<dt>归属</dt><dd>${esc(n.department)}</dd>` : ''}
          ${n.owner ? `<dt>负责人</dt><dd>${esc(n.owner)}</dd>` : ''}
          ${n.planStatus ? `<dt>规划状态</dt><dd>${planChip(n.planStatus)}</dd>` : ''}
          ${n.runStatus ? `<dt>运行状态</dt><dd>${chip(n.runStatus === 'RUNNING' ? 'chip--green' : 'chip--grey', n.runStatus === 'RUNNING' ? '运行中' : '未运行')}</dd>` : ''}
          ${n.skills && n.skills.length ? `<dt>技能</dt><dd>${n.skills.map((s) => `<span class="tag-plain">${esc(s)}</span>`).join(' ')}</dd>` : ''}
          ${n.tools && n.tools.length ? `<dt>工具</dt><dd>${n.tools.map((s) => `<span class="tag-plain">${esc(s)}</span>`).join(' ')}</dd>` : ''}
          ${n.services && n.services.length ? `<dt>服务</dt><dd>${n.services.map((s) => `<span class="tag-plain">${esc(s)}</span>`).join(' ')}</dd>` : ''}
        </dl>`, { narrow: true, foot: `<button class="btn" data-action="close-overlay">关闭详情</button>` });
    }
    if (o.key === 'workflow-drawer') {
      const wf = o.data ? D.workflows.find((x) => x.id === o.data) : null;
      return overlayDrawer(wf ? '编辑流程规划' : '新建流程规划', `
        <div style="display:flex;flex-direction:column;gap:18px">
          <div class="field"><label><span class="req">*</span>流程名称</label>
            <input class="input" placeholder="如：客户投诉处理流程" value="${esc(wf ? wf.workflowName : '')}"></div>
          <div class="form-grid" style="padding:0">
            <div class="field"><label>归属战略目标</label><select class="select">
              ${D.planGoals.map((g) => `<option ${wf && wf.goalId === g.id ? 'selected' : ''}>${esc(g.name)}（${esc(g.form)}）</option>`).join('')}</select></div>
            <div class="field"><label>优先级</label><select class="select">
              ${['P0', 'P1', 'P2'].map((p) => `<option ${wf && wf.priority === p ? 'selected' : ''}>${p}</option>`).join('')}</select></div>
            <div class="field"><label>期望上线</label><input class="input" type="date" value="${esc(wf ? wf.expectedOnline : '')}"></div>
            <div class="field"><label>预计年化节省</label><input class="input" placeholder="如：16,632 h/年" value="${esc(wf ? wf.value.saving : '')}"></div>
          </div>
          <div class="field"><label>参与的智能体</label>
            <div style="display:flex;flex-direction:column;gap:8px">
              ${((wf && wf.planAgents) ? wf.planAgents : [{ name: '', status: 'PLANNED' }]).map((node) => `<div style="display:flex;gap:8px;align-items:center">
                <span style="color:var(--text-mute)">⋮⋮</span>
                <select class="select" style="flex:1"><option>${esc(node.name)}</option></select>
                <select class="select" style="width:118px">${Object.keys(AGENT_STATUS).map((k) => `<option value="${k}" ${node.status === k ? 'selected' : ''}>${AGENT_STATUS[k][1]}</option>`).join('')}</select>
                <input class="input" style="flex:1" placeholder="计划上线 / 依赖" value="${esc(node.dependency || '')}">
                <button class="icon-btn" data-action="noop">−</button></div>`).join('')}
            </div>
            <button class="btn" style="margin-top:8px;align-self:flex-start" data-action="noop">${icon('plus', 14)} 添加智能体</button>
            <span class="hint">智能体状态决定流程可实施度：已上线 100 / 进行中 60 / 已排期 35 / 待实施 10。</span></div>
          <div class="field"><label>流程说明</label><textarea class="textarea" placeholder="请输入流程说明（选填）">${esc(wf ? wf.description : '')}</textarea></div>
          <div class="banner"><strong>编排与执行引擎</strong><br>当前为原型阶段的表单式录入，下一步将提供画布式可视化编排器，支持节点拖拽、分支编排与执行追踪。</div>
        </div>`, { foot: `<button class="btn" data-action="close-overlay">取消</button><button class="btn btn-primary" data-action="save-workflow">保存</button>` });
    }
    if (o.key === 'plan-detail') {
      const wf = D.workflows.find((x) => x.id === o.data);
      if (!wf) return '';
      const g = goalOf(wf);
      const r = planReadiness(wf);
      const blockers = planBlockers(wf);
      const counts = Object.keys(AGENT_STATUS).map((k) => [k, wf.planAgents.filter((a) => a.status === k).length]).filter((x) => x[1]);
      return overlayDrawer('流程规划详情', `
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
          <span class="avatar-sq" style="width:40px;height:40px;background:${readinessColor(r)}">${icon('flow', 18)}</span>
          <div><div style="font-size:17px;font-weight:600">${esc(wf.workflowName)}</div>
            <div style="font-size:12px;color:var(--text-mute)">${esc(wf.workflowCode)} · v${wf.revision} · ${esc(wf.owner)}</div></div>
          <div style="margin-left:auto;display:flex;gap:8px">${planStatusChip(wf.status)}${chip(wf.priority === 'P0' ? 'chip--red' : wf.priority === 'P1' ? 'chip--orange' : 'chip--grey', wf.priority)}</div>
        </div>

        <dl class="kv" style="margin-bottom:18px">
          <dt>归属战略目标</dt><dd>${esc(g.name || '—')} <span class="tag-plain">${esc(g.form || '')}</span> · 目标 ${esc(g.target || '—')} · 当前 ${esc(g.current || '—')}</dd>
          <dt>期望上线</dt><dd>${esc(wf.expectedOnline)}</dd>
          <dt>流程说明</dt><dd>${esc(wf.description)}</dd>
        </dl>

        <div class="plan-score">
          <div class="plan-score__value" style="color:${readinessColor(r)}">${r}<small>%</small></div>
          <div style="flex:1">
            <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:6px">
              <strong>流程可实施度</strong><span style="color:var(--text-sub)">${wf.planAgents.length - blockers.length}/${wf.planAgents.length} 个智能体已就绪</span></div>
            <div class="progress"><i style="width:${r}%;background:${readinessColor(r)}"></i></div>
            <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:10px">
              ${counts.map(([k, n]) => `<span class="chip ${AGENT_STATUS[k][0]}"><i class="dot"></i>${AGENT_STATUS[k][1]} ${n}</span>`).join('')}
            </div>
          </div>
        </div>

        ${blockers.length ? `<div class="banner banner--warn" style="margin-top:16px">
          <div><strong>规划阻塞：${blockers.length} 个智能体待实施</strong><br>
          ${blockers.map((b) => `${esc(b.name)}（${esc(b.dependency)}）`).join('、')} —— 上线后方可全流程贯通，建议优先排期。</div></div>` : ''}

        <h4 style="margin:20px 0 8px;font-size:14px">涉及智能体（${wf.planAgents.length}）</h4>
        <table class="data"><thead><tr><th>智能体</th><th>状态</th><th>计划上线</th><th>依赖</th><th>备注</th></tr></thead>
        <tbody>${wf.planAgents.map((a) => `<tr>
          <td><div class="cell-name"><span class="avatar-sq" style="background:${STATUS_COLOR[a.status]}">${esc(a.name.slice(0, 1))}</span>
            <div><div>${esc(a.name)}</div><small>${esc(a.id)}</small></div></div></td>
          <td>${agentChip(a.status)}</td><td>${esc(a.online)}</td><td>${esc(a.dependency)}</td>
          <td style="color:var(--text-sub)">${esc(a.note || '—')}</td></tr>`).join('')}</tbody></table>

        <h4 style="margin:20px 0 8px;font-size:14px">规划价值测算</h4>
        <div class="value-grid">
          <div class="value-card"><span>预计节省工时</span><strong>${esc(wf.value.saving)}</strong></div>
          <div class="value-card"><span>覆盖用户</span><strong>${esc(wf.value.coverage)}</strong></div>
          <div class="value-card"><span>业务价值评分</span><strong>${wf.value.score}<small> / 100</small></strong></div>
          <div class="value-card"><span>投入产出比（ROI）</span><strong>${esc(wf.value.roi)}</strong></div>
        </div>`,
        { foot: `<button class="btn" data-action="close-overlay">关闭详情</button>
          <button class="btn" data-action="workflow-edit" data-id="${wf.id}">编辑规划</button>
          <button class="btn btn-primary" data-action="plan-approve" data-id="${wf.id}">提交评审</button>` });
    }
    if (o.key === 'intake-create') {
      return overlayDrawer('新建需求', `
        <div class="form-grid" style="padding:0">
          <div class="field"><label><span class="req">*</span>需求类型</label><select class="select">
            <option>Demand 需求</option><option>Product idea 产品构想</option><option>Feedback 反馈</option></select></div>
          <div class="field"><label><span class="req">*</span>需求标题</label><input class="input" placeholder="如：客服投诉全流程自动化"></div>
          <div class="field"><label><span class="req">*</span>来源</label><input class="input" placeholder="如：客户服务部"></div>
          <div class="field"><label><span class="req">*</span>负责人</label><input class="input" placeholder="填写负责人姓名"></div>
          <div class="field"><label>期望价值</label><input class="input" placeholder="如：首响时间 -30%"></div>
          <div class="field"><label>优先级</label><select class="select"><option>P0</option><option>P1</option><option>P2</option></select></div>
          <div class="field"><label>归属战略目标</label><select class="select">
            ${D.planGoals.map((g) => `<option>${esc(g.name)}（${esc(g.form)}）</option>`).join('')}</select></div>
          <div class="field"><label>期望上线</label><input class="input" type="date"></div>
          <div class="field full"><label>需求描述</label><textarea class="textarea" placeholder="描述业务痛点、期望效果与约束条件"></textarea></div>
        </div>
        <div class="banner" style="margin-top:14px">提交后进入「待评审」，评审通过可由需求直接分流为一条流程规划。</div>`,
        { foot: `<button class="btn" data-action="close-overlay">取消</button><button class="btn btn-primary" data-action="save-intake">提交需求</button>` });
    }
    if (o.key === 'intake-detail') {
      const x = D.planIntake.find((y) => y.id === o.data) || {};
      const g = D.planGoals.find((y) => y.id === x.goalId) || {};
      const wf = D.workflows.find((y) => y.id === x.relatedWorkflow);
      return overlayDrawer('需求详情', `
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
          <span class="avatar-sq" style="width:38px;height:38px;background:#2563eb">${icon('inbox', 17)}</span>
          <div><div style="font-size:16px;font-weight:600">${esc(x.title)}</div>
            <div style="font-size:12px;color:var(--text-mute)">${esc(x.id)} · ${esc(x.source)}</div></div>
          <div style="margin-left:auto;display:flex;gap:8px">${chip(INTAKE_TYPE[x.type][0], INTAKE_TYPE[x.type][1])}${chip(INTAKE_STATUS[x.status], x.status)}</div>
        </div>
        <dl class="kv">
          <dt>期望价值</dt><dd>${esc(x.expectedValue)}</dd>
          <dt>归属战略目标</dt><dd>${esc(g.name || '—')} <span class="tag-plain">${esc(g.form || '')}</span></dd>
          <dt>关联流程</dt><dd>${esc(wf ? wf.workflowName : '尚未生成流程规划')}</dd>
          <dt>优先级</dt><dd>${esc(x.priority)}</dd>
          <dt>负责人</dt><dd>${esc(x.owner)}</dd>
          <dt>提交时间</dt><dd>${esc(x.submittedAt)}</dd>
          <dt>评审说明</dt><dd>${esc(x.note)}</dd>
        </dl>
        ${wf ? `<div class="plan-score" style="margin-top:16px">
          <div class="plan-score__value" style="color:${readinessColor(planReadiness(wf))}">${planReadiness(wf)}<small>%</small></div>
          <div style="flex:1"><div style="font-size:13px;margin-bottom:6px"><strong>已生成流程规划：${esc(wf.workflowName)}</strong></div>
            <div class="progress"><i style="width:${planReadiness(wf)}%;background:${readinessColor(planReadiness(wf))}"></i></div>
            <div style="font-size:12px;color:var(--text-sub);margin-top:8px">涉及 ${wf.planAgents.length} 个智能体 · 预计节省 ${esc(wf.value.saving)}</div></div>
        </div>` : ''}`,
        { narrow: true, foot: `<button class="btn" data-action="close-overlay">关闭</button>
          ${wf ? `<button class="btn btn-primary" data-action="plan-detail" data-id="${wf.id}">查看流程规划</button>`
            : `<button class="btn btn-primary" data-action="intake-convert" data-id="${x.id}">转为流程规划</button>`}` });
    }
    if (o.key === 'kb-create' || o.key === 'kb-edit') {
      const kb = o.key === 'kb-edit' ? D.knowledgeBases.find((x) => x.id === o.data) : null;
      return overlayDrawer(kb ? '编辑知识库' : '新增知识库', `
        <div class="form-grid" style="padding:0">
          <div class="field"><label><span class="req">*</span>标识</label><input class="input" placeholder="如：1001" value="${esc(kb ? kb.knowledgeId : '')}"></div>
          <div class="field"><label><span class="req">*</span>名称</label><input class="input" placeholder="如：产品知识库" value="${esc(kb ? kb.name : '')}"></div>
          <div class="field"><label><span class="req">*</span>知识库类型</label><select class="select"><option ${kb && kb.type === 'RAG' ? 'selected' : ''}>RAG</option><option ${kb && kb.type === 'VECTOR' ? 'selected' : ''}>向量库</option></select></div>
          <div class="field"><label><span class="req">*</span>来源类型</label><select class="select"><option>APIH</option><option>其他</option></select></div>
          <div class="field"><label>启用状态</label><select class="select"><option>启用</option><option>禁用</option></select></div>
          <div class="field full"><label>描述</label><textarea class="textarea" placeholder="描述知识库内容与用途">${esc(kb ? kb.description : '')}</textarea></div>
        </div>`, { foot: `<button class="btn" data-action="close-overlay">取消</button><button class="btn btn-primary" data-action="save">确定</button>` });
    }
    if (o.key === 'kpi-drawer') {
      const k = o.data ? D.kpiDefinitions.find((x) => x.id === o.data) : null;
      return overlayDrawer(k ? '编辑 KPI 指标' : '新增 KPI 指标', `
        <div class="form-grid" style="padding:0">
          <div class="field"><label><span class="req">*</span>所属 Agent</label><select class="select">${D.agents.map((a) => `<option ${k && k.agentId === a.id ? 'selected' : ''}>${esc(a.name)}</option>`).join('')}</select></div>
          <div class="field"><label><span class="req">*</span>指标名称</label><input class="input" placeholder="例如：关键决策点 AI 参与率" value="${esc(k ? k.metricName : '')}"></div>
          <div class="field"><label>指标分类</label><select class="select"><option>技术表现</option><option>采用指标</option><option>运营 KPI</option></select></div>
          <div class="field"><label>目标类型</label><select class="select"><option>单值目标</option><option>周期达成目标</option></select></div>
          <div class="field full"><label><span class="req">*</span>计算逻辑</label><textarea class="textarea" placeholder="描述数据来源、统计范围和计算公式">${esc(k ? k.calculationLogic : '')}</textarea></div>
          <div class="field"><label>目标规则</label>
            <div style="display:flex;gap:8px"><select class="select" style="width:88px"><option>&gt;=</option><option>&lt;=</option><option>&gt;</option><option>&lt;</option><option>=</option></select>
            <input class="input" value="${esc(k ? k.targetValue : '')}"><select class="select" style="width:110px"><option>数值</option><option>%</option><option>秒</option><option>小时</option></select></div></div>
          <div class="field"><label>启用指标</label><select class="select"><option>启用</option><option>停用</option></select></div>
        </div>
        <div class="banner" style="margin-top:16px"><strong>指标值数据</strong><br>填写后将在保存指标定义的同时新增一条当前观测数据。</div>`,
        { foot: `<button class="btn" data-action="close-overlay">取消</button><button class="btn btn-primary" data-action="save">保存</button>` });
    }
    if (o.key === 'tenant-create' || o.key === 'tenant-edit') {
      const x = o.key === 'tenant-edit' ? D.tenants.find((y) => y.id === o.data) : null;
      return overlayModal(x ? '编辑空间' : '创建空间', `
        <div class="form-grid" style="padding:0">
          <div class="field"><label><span class="req">*</span>空间名称</label><input class="input" placeholder="请输入空间名称" value="${esc(x ? x.wsName : '')}"></div>
          <div class="field"><label><span class="req">*</span>空间编码</label>
            <div style="display:flex;gap:8px"><input class="input" placeholder="如 space_001" value="${esc(x ? x.wsCode : '')}">
            <button class="btn" data-action="noop">随机生成</button></div></div>
          <div class="field"><label><span class="req">*</span>创建人</label><input class="input" value="${esc(x ? x.ownerId : state.user.itCode)}" readonly></div>
          <div class="field"><label><span class="req">*</span>所属组织</label><input class="input" placeholder="请输入所属组织" value="${esc(x ? x.department : '')}"></div>
          <div class="field full"><label><span class="req">*</span>空间描述</label><textarea class="textarea" placeholder="简要描述空间的定位、服务对象和主要能力。">${esc(x ? x.wsDescription : '')}</textarea></div>
        </div>
        <div class="banner" style="margin-top:14px">${x ? '保存后将更新空间基础信息，不影响当前使用状态。' : '提交后自动生成申请时间，初始状态为“使用中”。'}</div>`,
        { wide: true, foot: `<button class="btn" data-action="close-overlay">取消</button><button class="btn btn-primary" data-action="save">${x ? '保存' : '创建'}</button>` });
    }
    if (o.key === 'user-create' || o.key === 'user-edit') {
      const u = o.key === 'user-edit' ? D.members.find((x) => x.id === o.data) : null;
      return overlayModal(u ? '编辑用户' : '添加用户', `
        <div class="form-grid" style="padding:0">
          <div class="field"><label><span class="req">*</span>ItCode</label><input class="input" placeholder="请输入 ItCode" value="${esc(u ? u.userId : '')}"></div>
          <div class="field"><label><span class="req">*</span>邮箱</label><input class="input" placeholder="请输入邮箱" value="${esc(u ? u.email : '')}"></div>
          <div class="field"><label><span class="req">*</span>角色</label><select class="select">
            ${state.wsCode === SYS_WS ? `<option value="sys_admin" ${u && u.role === 'sys_admin' ? 'selected' : ''}>平台管理员</option>`
              : `<option value="ws_admin" ${u && u.role === 'ws_admin' ? 'selected' : ''}>空间管理员</option><option value="ws_basic" ${u && u.role === 'ws_basic' ? 'selected' : ''}>空间用户</option>`}
          </select></div>
        </div>`, { foot: `<button class="btn" data-action="close-overlay">取消</button><button class="btn btn-primary" data-action="save">保存</button>` });
    }
    if (o.key === 'cmdb') {
      return overlayModal('CMDB Application', `
        <div class="filter-bar" style="padding:0 0 12px;border:none">
          <input class="input" placeholder="搜索 Application Id">
          <input class="input" placeholder="搜索 Application Name">
          <button class="btn">搜索</button></div>
        <table class="data"><thead><tr><th>Application Id</th><th>Application Name</th><th>Application Full Name</th><th>负责人</th><th>操作</th></tr></thead>
        <tbody>${D.cmdb.map((c) => `<tr><td>${esc(c.id)}</td><td>${esc(c.name)}</td><td>${esc(c.fullName)}</td><td>${esc(c.owner)}</td>
          <td><button class="btn btn-sm btn-primary" data-action="cmdb-pick" data-value="${esc(c.id)}">选择</button></td></tr>`).join('')}</tbody></table>`,
        { wide: true, foot: `<button class="btn" data-action="close-overlay">取消</button>` });
    }
    if (o.key === 'approval-detail') {
      const r = D.applications.find((x) => x.id === o.data) || {};
      return overlayModal('智能体注册申请详情', `
        <dl class="kv">
          <dt>智能体标识</dt><dd>${esc(r.agentCode)}</dd>
          <dt>名称</dt><dd>${esc(r.name)}</dd>
          <dt>展示名称</dt><dd>${esc(r.displayName)}</dd>
          <dt>版本</dt><dd>${esc(r.versionTag)}</dd>
          <dt>所属部门</dt><dd>${esc(r.department)}</dd>
          <dt>负责人</dt><dd>${esc(r.owner)} · ${esc(r.email)}</dd>
          <dt>模型</dt><dd>${esc(r.model)}</dd>
          <dt>标签</dt><dd>${(r.tags || []).map((x) => `<span class="tag-plain">${esc(x)}</span>`).join(' ')}</dd>
          <dt>能力描述</dt><dd>${esc(r.description)}</dd>
          <dt>申请时间</dt><dd>${esc(stamp(r.createdAt))}</dd>
        </dl>`,
        { foot: `<button class="btn" data-action="close-overlay">关闭</button>
          <button class="btn btn-primary" data-action="approval-approve" data-id="${esc(r.id)}">${t('通过')}</button>` });
    }
    if (o.key === 'reject') {
      const r = D.applications.find((x) => x.id === o.data) || {};
      return overlayModal('驳回智能体注册申请', `
        <div class="field"><label><span class="req">*</span>驳回原因</label>
          <textarea class="textarea" placeholder="请填写驳回原因"></textarea>
          <span class="hint">驳回后申请人可修改信息并重新提交。</span></div>
        <p style="color:var(--text-sub);font-size:13px">申请：${esc(r.name)} · ${esc(r.owner)}</p>`,
        { foot: `<button class="btn" data-action="close-overlay">取消</button><button class="btn btn-danger" data-action="confirm-reject">确认驳回</button>` });
    }
    if (o.key === 'confirm-delete') {
      return overlayModal('删除确认', `<p style="margin:0;font-size:14px">${esc(o.data.text)}</p>
        <p style="color:var(--text-sub);font-size:13px">删除后不可恢复。</p>`,
        { foot: `<button class="btn" data-action="close-overlay">取消</button><button class="btn btn-danger" data-action="confirm-delete">确认删除</button>` });
    }
    if (o.key === 'help') {
      return overlayDrawer('原型使用说明', `
        <ul class="help-list">
          <li>右上角用户菜单可“切换身份”，演示 RBAC 可见性（空间管理仅平台用户可见；删除智能体需管理员）。</li>
          <li>右上角语言切换（中/EN）：原型阶段覆盖框架级文案（导航/顶栏/页面标题/按钮），正文示例数据保持中文。</li>
          <li>顶栏“空间切换”演示多空间上下文（平台视角 / 各业务空间），切换后左侧菜单与首页会随空间变化。</li>
          <li>智能体注册页：填写申请 → 底部“下一步”进入能力与技能 → 提交后可在“智能体审批”中通过。</li>
          <li>拓扑图页支持节点点选与右侧节点详情抽屉；流程全局视图展示流程与智能体的关联关系。</li>
          <li>列表中带下划线的按钮均可点击，演示抽屉 / 弹窗 / 二次确认等交互。</li>
        </ul>
        <div class="banner" style="margin-top:16px">本原型基于现网 SIT 前端（路由、文案、表头与交互）还原；数据为演示数据。</div>`,
        { narrow: true, foot: `<button class="btn" data-action="close-overlay">知道了</button>` });
    }
    return '';
  }

  function overlayDrawer(title, body, opts) {
    const o = opts || {};
    return `<div class="overlay overlay--drawer" data-action="mask">
      <div class="drawer ${o.narrow ? 'drawer--narrow' : ''}">
        <div class="drawer__head"><h3>${esc(title)}</h3><button class="close-x" data-action="close-overlay">✕</button></div>
        <div class="drawer__body">${body}</div>
        ${o.foot === '' ? '' : `<div class="drawer__foot">${o.foot || ''}</div>`}
      </div></div>`;
  }

  function overlayModal(title, body, opts) {
    const o = opts || {};
    return `<div class="overlay overlay--center" data-action="mask">
      <div class="modal ${o.wide ? 'modal--wide' : ''}">
        <div class="modal__head"><h3>${esc(title)}</h3><button class="close-x" data-action="close-overlay">✕</button></div>
        <div class="modal__body">${body}</div>
        <div class="modal__foot">${o.foot || ''}</div>
      </div></div>`;
  }

  /* ------------------------------ 渲染 ------------------------------ */
  function render() {
    const root = document.getElementById('app');
    if (state.route === 'login') {
      root.innerHTML = renderLogin();
      return;
    }
    window.ACP_POLICY.setContext({role:currentRole(), ws:state.wsCode}, render, navigate, toast);
    window.ACP_COLLAB.onRoute(state.route);
    window.ACP_COLLAB.setContext({role:currentRole(), ws:state.wsCode}, render, navigate, toast);
    root.innerHTML = renderShell(renderView() + window.ACP_POLICY.builtinPanel(state.route)) + renderOverlay() + window.ACP_POLICY.overlay() + window.ACP_COLLAB.overlay() +
      `<div id="toast" class="hidden" style="position:fixed;left:50%;top:18px;transform:translateX(-50%);background:#fff;border:1px solid var(--line);border-radius:8px;padding:8px 16px;box-shadow:var(--shadow-lg);font-size:13px;z-index:80"></div>`;
    if (state.toast) {
      const el = document.getElementById('toast');
      el.textContent = state.toast;
      el.classList.remove('hidden');
    }
  }

  function renderLogin() {
    return `<div class="login">
      <div class="login__brand">
        <div class="login__logo"><div class="login__logo-mark">ACP</div>
          <div class="login__logo-text"><strong>Agent Control Plane</strong><span>Control Plane</span></div></div>
        <div class="login__hero"><h1>Lenovo Enterprise<br>Agent Control Plane</h1>
          <p>Control Plane 为企业提供一体化的 AI 智能体调度与治理能力。通过集成的控制平面，您可以轻松实现大规模 Agent 的生命周期管理、策略配置与实时协作干预。</p></div>
        <div class="login__foot"><span>系统在线率 99.98%</span><span>日均任务吞吐 1.2M</span></div>
      </div>
      <div class="login__panel"><div class="login__form">
        <h2>欢迎回来</h2><p>请使用联想账号登录以访问控制中心</p>
        <button class="login__adfs" data-action="fake-login">使用 Lenovo-ADFS 登录</button>
        <div class="login__divider">受保护的内部连接</div>
        <div class="login__hint">访问此系统需要有效的联想员工或合作伙伴 AD 凭据。如果您在登录时遇到问题，请联系 IT 部门或通过 ADFS 门户重置密码。</div>
        <p style="margin-top:16px;font-size:12px;color:var(--text-mute)">原型说明：现网环境登录会跳转 Keycloak（taip-auth-tst.lenovo.com/realms/myapp）。原型中点击即可进入控制台。</p>
      </div></div>
      <div class="login__meta"><div class="seg"><button class="${state.locale === 'zh-CN' ? 'on' : ''}" data-action="locale" data-value="zh-CN">中文</button>
        <button class="${state.locale === 'en-US' ? 'on' : ''}" data-action="locale" data-value="en-US">EN</button></div>
        <span>v1.0.0</span><span>CN-SH-CL-01</span></div>
    </div>`;
  }

  /* ------------------------------ 交互 ------------------------------ */
  const ROUTES = ["collab-list","collab-detail","collab-overview","collab-runs","collab-trace","collab-errors","policy-collab-admission","policy-collab-control","policy-collab-hits",'policy-overview', 'policy-list', 'policy-assignments', 'policy-records', 'overview', 'system-dashboard', 'agent-list', 'agent-register', 'agent-approval', 'agent-topology',
    'plan-overview', 'plan-workflows', 'plan-intake', 'workflow-global', 'mcp-services', 'knowledge-bases', 'model-access', 'agent-kpi',
    'kpi-maintenance', 'settings-tenants', 'settings-users', 'login'];

  function navigate(route) {
    if (!ROUTES.includes(route)) route = 'overview';
    if (route === 'settings-tenants' && state.wsCode !== SYS_WS) { route = 'overview'; toast('空间管理仅平台用户可见'); }
    state.route = route;
    state.overlay = null;
    state.userMenu = false;
    state.selectedNode = null;
    location.hash = route === 'login' ? '#/login' : `#/${route}`;
    render();
  }

  document.addEventListener('click', (ev) => {
    const el = ev.target.closest('[data-action],[data-nav]');
    if (!el) return;
    const nav = el.getAttribute('data-nav');
    if (nav) {
      if (nav === 'settings-tenants' && state.wsCode !== SYS_WS) { toast('空间管理仅平台用户可见'); return; }
      navigate(nav);
      return;
    }
    const action = el.getAttribute('data-action');
    const id = el.getAttribute('data-id');
    const value = el.getAttribute('data-value');
    switch (action) {
      case 'fake-login': navigate('overview'); break;
      case 'locale': state.locale = value; store.set('acp-prototype-locale', value); render(); break;
      case 'help': state.overlay = { key: 'help' }; render(); break;
      case 'user-menu': state.userMenu = !state.userMenu; render(); break;
      case 'identity':
        state.identity = value; store.set('acp-prototype-identity', value);
        state.userMenu = false; render();
        toast(`已切换身份：${ROLE_LABEL[currentRole()]}`);
        break;
      case 'logout': state.userMenu = false; navigate('login'); break;
      case 'refresh': toast('数据已刷新'); break;
      case 'reset-filter': state.filters[el.getAttribute('data-scope')] = {}; render(); break;
      case 'close-overlay': state.overlay = null; render(); break;
      case 'mask': if (ev.target === el) { state.overlay = null; render(); } break;
      case 'noop': toast('原型演示：该操作已省略'); break;
      case 'save': case 'save-workflow': state.overlay = null; render(); toast('保存成功'); break;
      case 'agent-detail': state.overlay = { key: 'agent-detail', data: id }; render(); break;
      case 'agent-history': state.overlay = { key: 'agent-history', data: id }; render(); break;
      case 'agent-edit':
        if (currentRole() === 'ws_basic') { toast('仅草稿和已驳回的智能体可编辑'); break; }
        state.overlay = { key: 'agent-detail', data: id }; render(); break;
      case 'agent-delete': {
        if (currentRole() === 'ws_basic') { toast('删除智能体需管理员权限'); break; }
        const a = D.agents.find((x) => x.id === id);
        state.overlay = { key: 'confirm-delete', data: { text: `确定要删除智能体「${a.name}」吗？` } };
        render(); break;
      }
      case 'confirm-delete': state.overlay = null; render(); toast('删除成功'); break;
      case 'version-approve': toast('智能体版本已通过'); break;
      case 'version-reject': toast('智能体版本已驳回'); break;
      case 'wizard-next': state.wizard.step = Math.min(3, state.wizard.step + 1); render(); break;
      case 'wizard-prev': state.wizard.step = Math.max(1, state.wizard.step - 1); render(); break;
      case 'wizard-tab': state.wizard.tab = value; render(); break;
      case 'wizard-submit': state.wizard.step = 1; navigate('agent-approval'); toast('智能体注册申请已提交，等待空间管理员审批'); break;
      case 'cmdb': state.overlay = { key: 'cmdb' }; render(); break;
      case 'cmdb-pick': state.wizard.cmdb = `${value} · 联想智能客服平台`; state.overlay = null; render(); break;
      case 'approval-detail': state.overlay = { key: 'approval-detail', data: id }; render(); break;
      case 'approval-approve': {
        if (currentRole() === 'ws_basic') { toast('仅当前空间管理员可审批'); break; }
        state.overlay = null; render(); toast('智能体审批已通过，正在生成 Non-Human Identity'); break;
      }
      case 'approval-reject':
        if (currentRole() === 'ws_basic') { toast('仅当前空间管理员可审批'); break; }
        state.overlay = { key: 'reject', data: id }; render(); break;
      case 'confirm-reject': state.overlay = null; render(); toast('智能体注册申请已驳回'); break;
      case 'topo-node': state.selectedNode = state.selectedNode === id ? null : id; state.overlay = { key: 'topo-node', data: id }; render(); break;
      case 'workflow-create': state.overlay = { key: 'workflow-drawer', data: null }; render(); break;
      case 'workflow-edit': state.overlay = { key: 'workflow-drawer', data: id }; render(); break;
      case 'workflow-view': navigate('workflow-global'); toast('已跳转流程全局视图'); break;
      case 'plan-detail': state.overlay = { key: 'plan-detail', data: id }; render(); break;
      case 'plan-approve': state.overlay = null; render(); toast('流程规划已提交评审'); break;
      case 'intake-tab': state.intakeTab = value; render(); break;
      case 'intake-create': state.overlay = { key: 'intake-create' }; render(); break;
      case 'intake-detail': state.overlay = { key: 'intake-detail', data: id }; render(); break;
      case 'save-intake': state.overlay = null; render(); toast('需求已提交，等待评审分流'); break;
      case 'intake-convert': state.overlay = null; render(); toast('已分流为流程规划，等待补充智能体与排期'); break;
      case 'workflow-delete': {
        const w = D.workflows.find((x) => x.id === id);
        state.overlay = { key: 'confirm-delete', data: { text: `确定要删除流程「${w.workflowName}」吗？` } };
        render(); break;
      }
      case 'kb-create': state.overlay = { key: 'kb-create' }; render(); break;
      case 'kb-edit': state.overlay = { key: 'kb-edit', data: id }; render(); break;
      case 'kb-delete': {
        const k = D.knowledgeBases.find((x) => String(x.id) === String(id));
        state.overlay = { key: 'confirm-delete', data: { text: `确定要删除知识库「${k.name}」吗？` } };
        render(); break;
      }
      case 'kpi-create': state.overlay = { key: 'kpi-drawer', data: null }; render(); break;
      case 'kpi-edit': state.overlay = { key: 'kpi-drawer', data: id }; render(); break;
      case 'kpi-delete': {
        const k = D.kpiDefinitions.find((x) => x.id === id);
        state.overlay = { key: 'confirm-delete', data: { text: `确定删除「${k.metricName}」吗？` } };
        render(); break;
      }
      case 'tenant-create': state.overlay = { key: 'tenant-create' }; render(); break;
      case 'tenant-edit': state.overlay = { key: 'tenant-edit', data: id }; render(); break;
      case 'tenant-detail': {
        const x = D.tenants.find((y) => String(y.id) === String(id));
        toast(`${x.wsName}：${x.wsDescription}`);
        break;
      }
      case 'tenant-toggle': toast('空间状态已更新'); break;
      case 'tenant-users': navigate('settings-users'); break;
      case 'user-create': state.overlay = { key: 'user-create' }; render(); break;
      case 'user-edit': state.overlay = { key: 'user-edit', data: id }; render(); break;
      case 'user-toggle': toast('用户状态已更新'); break;
      case 'user-remove': {
        const u = D.members.find((x) => String(x.id) === String(id));
        state.overlay = { key: 'confirm-delete', data: { text: `移除后，${u.userName} 将无法访问当前平台。` } };
        render(); break;
      }
      default: break;
    }
  });

  document.addEventListener('input', (ev) => {
    const key = ev.target.getAttribute && ev.target.getAttribute('data-filter');
    if (key) {
      const [scope, field] = key.split('.');
      state.filters[scope] = state.filters[scope] || {};
      state.filters[scope][field] = ev.target.value;
      clearTimeout(window.__filterTimer);
      window.__filterTimer = setTimeout(render, 220);
      return;
    }
    if (ev.target.getAttribute && ev.target.getAttribute('data-action') === 'ws-switch') {
      state.wsCode = ev.target.value;
      store.set('acp-prototype-ws', state.wsCode);
      state.overlay = null;
      if (state.route === 'settings-tenants' && state.wsCode !== SYS_WS) state.route = 'overview';
      if (state.route === 'overview' && state.wsCode === SYS_WS) state.route = 'system-dashboard';
      if (state.route === 'system-dashboard' && state.wsCode !== SYS_WS) state.route = 'overview';
      toast(`已切换空间：${currentWorkspace().wsName}（当前身份 ${ROLE_LABEL[currentRole()]}）`);
      render();
    }
  });

  document.addEventListener('change', (ev) => {
    if (ev.target.getAttribute && ev.target.getAttribute('data-action') === 'ws-switch') {
      ev.target.dispatchEvent(new Event('input', { bubbles: true }));
    }
  });

  window.addEventListener('hashchange', () => {
    const route = location.hash.replace(/^#\/?/, '') || 'overview';
    if (route !== state.route) { state.route = ROUTES.includes(route) ? route : 'overview'; render(); }
  });

  /* ------------------------------ 启动 ------------------------------ */
  const initial = location.hash.replace(/^#\/?/, '');
  state.route = ROUTES.includes(initial) ? initial : 'login';
  render();
  window.ACP = { state, navigate };
})();
