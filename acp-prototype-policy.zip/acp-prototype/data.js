/* 原型演示数据：字段命名对齐 ACP 控制平面接口契约（/acp-api/v1/{wsCode}/...）。 */
window.ACP_DATA = (function () {
  const now = Date.now();
  const ago = (min) => new Date(now - min * 60000).toISOString();

  const workspaces = [
    { id: 1, wsCode: 'acp-ws-sys', wsName: '系统管理空间', userRole: 'sys_admin' },
    { id: 2, wsCode: 'ws-agent-ops', wsName: '智能体运营空间', userRole: 'ws_admin' },
    { id: 3, wsCode: 'ws-customer-svc', wsName: '智能客服空间', userRole: 'ws_basic' },
  ];

  const departments = ['智能客服部', '法务部', '研发中心', '财务部', '市场部', '人力资源部', '销售部'];

  const agents = [
    { id: 'agent-1001', agentCode: 'customer_service', name: '客服问答智能体', displayName: 'AI 客服助手', version: '1.4.2', department: '智能客服部', category: 'services', categoryGroup: '客户体验组', owner: '王敏', ownerEmail: 'wangmin3@lenovo.com', type: 'AI Gateway', dataCenter: 'CN-SH-CL-01', planStatus: 'LIVE', auditStatus: 'PUBLISHED', runStatus: 'RUNNING', model: 'GPT-4.1', skills: ['FAQ 问答', '工单分类', '情绪识别'], apiCount: 12, todayCalls: 18432, lastSyncAt: ago(6), pendingChanges: 1, description: '面向消费者业务线的智能客服助手，覆盖售前咨询、售后工单与退款流程。', tags: ['客服', '售前', '售后'], services: ['订单查询', '退款申请'], tools: ['工单查询', '知识检索'] },
    { id: 'agent-1002', agentCode: 'contract_review', name: '合同审查智能体', displayName: '法务合同审查', version: '0.9.1', department: '法务部', category: 'legal', categoryGroup: '法务合规组', owner: '李强', ownerEmail: 'liqiang7@lenovo.com', type: 'Agent IAM', dataCenter: 'CN-SH-CL-01', planStatus: 'WIP', auditStatus: 'REVIEWING', runStatus: 'RUNNING', model: 'Claude-Sonnet', skills: ['条款抽取', '风险标注'], apiCount: 5, todayCalls: 2360, lastSyncAt: ago(180), pendingChanges: 0, description: '对采购与销售合同做条款抽取、风险标注与合规检查。', tags: ['法务', '合规'], services: ['合同归档'], tools: ['合同解析'] },
    { id: 'agent-1003', agentCode: 'code_assistant', name: '研发编码助手', displayName: 'Copilot 编码助手', version: '2.0.0', department: '研发中心', category: 'products', categoryGroup: '研发效能组', owner: '陈涛', ownerEmail: 'chentao5@lenovo.com', type: 'AI Gateway', dataCenter: 'CN-BJ-DC-02', planStatus: 'LIVE', auditStatus: 'PUBLISHED', runStatus: 'RUNNING', model: 'GPT-4.1', skills: ['代码补全', '单测生成', '代码评审'], apiCount: 21, todayCalls: 42310, lastSyncAt: ago(12), pendingChanges: 0, description: '研发全流程编码助手，覆盖补全、单测生成与代码评审建议。', tags: ['研发', '效能'], services: ['制品库'], tools: ['代码检索'] },
    { id: 'agent-1004', agentCode: 'finance_report', name: '财务报表智能体', displayName: '财务月报助手', version: '1.1.0', department: '财务部', category: 'analytics', categoryGroup: '财务分析组', owner: '赵蕾', ownerEmail: 'zhaolei2@lenovo.com', type: 'AI Gateway', dataCenter: 'CN-SH-CL-01', planStatus: 'SCHEDULED', auditStatus: 'DRAFT', runStatus: 'STOPPED', model: 'Qwen-Max', skills: ['报表汇总', '异常检测'], apiCount: 3, todayCalls: 0, lastSyncAt: ago(2880), pendingChanges: 0, description: '自动汇总各业务单元报表并做异常波动提示。', tags: ['财务'], services: [], tools: [] },
    { id: 'agent-1005', agentCode: 'market_insight', name: '市场洞察智能体', displayName: '市场洞察助手', version: '0.4.0', department: '市场部', category: 'marketing', categoryGroup: '品牌营销组', owner: '孙悦', ownerEmail: 'sunyue1@lenovo.com', type: 'AI Gateway', dataCenter: 'CN-SH-CL-01', planStatus: 'PLANNED', auditStatus: 'REJECTED', runStatus: 'OFFLINE', model: 'DeepSeek-V3', skills: ['舆情摘要'], apiCount: 2, todayCalls: 0, lastSyncAt: ago(7200), pendingChanges: 0, description: '聚合社媒与行业资讯，输出竞品与舆情洞察摘要。', tags: ['市场'], services: [], tools: [] },
    { id: 'agent-1006', agentCode: 'hr_policy', name: '人事政策智能体', displayName: 'HR 政策问答', version: '1.0.3', department: '人力资源部', category: 'hr', categoryGroup: '员工服务组', owner: '周琳', ownerEmail: 'zhoulin4@lenovo.com', type: 'Agent IAM', dataCenter: 'CN-SH-CL-01', planStatus: 'LIVE', auditStatus: 'PUBLISHED', runStatus: 'RUNNING', model: 'Qwen-Max', skills: ['政策问答', '假勤计算'], apiCount: 8, todayCalls: 9120, lastSyncAt: ago(45), pendingChanges: 0, description: '面向全体员工的人事政策问答与假勤规则计算助手。', tags: ['人事'], services: ['HR 主数据'], tools: [] },
    { id: 'agent-1007', agentCode: 'sales_copilot', name: '销售作战智能体', displayName: '销售作战助手', version: '1.2.5', department: '销售部', category: 'sales', categoryGroup: '渠道销售组', owner: '吴迪', ownerEmail: 'wudi6@lenovo.com', type: 'AI Gateway', dataCenter: 'CN-BJ-DC-02', planStatus: 'WIP', auditStatus: 'REVIEWING', runStatus: 'RUNNING', model: 'GPT-4.1', skills: ['商机评分', '话术建议'], apiCount: 9, todayCalls: 5320, lastSyncAt: ago(18), pendingChanges: 2, description: '为渠道销售提供商机评分、拜访准备与话术建议。', tags: ['销售', '渠道'], services: ['CRM'], tools: ['商机查询'] },
    { id: 'agent-1008', agentCode: 'doc_knowledge', name: '文档知识智能体', displayName: '内部知识问答', version: '1.0.0', department: '研发中心', category: 'analytics', categoryGroup: '研发效能组', owner: '郑浩', ownerEmail: 'zhenghao8@lenovo.com', type: 'Agent IAM', dataCenter: 'CN-SH-CL-01', planStatus: 'LIVE', auditStatus: 'PUBLISHED', runStatus: 'RUNNING', model: 'DeepSeek-V3', skills: ['文档检索', '答案生成'], apiCount: 6, todayCalls: 6710, lastSyncAt: ago(90), pendingChanges: 0, description: '基于内部文档知识库的检索增强问答助手。', tags: ['知识库'], services: ['知识库'], tools: ['向量检索'] },
  ];

  const applications = [
    { id: 'app-2001', agentId: 'agent-1009', agentCode: 'bid_document', name: '投标文件智能体', displayName: '投标文件助手', department: '销售部', owner: '何静', email: 'hejing3@lenovo.com', createdAt: ago(360), auditStatus: 'PENDING', versionTag: 'v0.1.0', model: 'GPT-4.1', description: '自动生成投标文件初稿并做资质匹配，减少标书准备时间。', tags: ['销售', '投标'] },
    { id: 'app-2002', agentId: 'agent-1010', agentCode: 'supplier_risk', name: '供应商风险智能体', displayName: '供应商风险助手', department: '法务部', owner: '刘洋', email: 'liuyang9@lenovo.com', createdAt: ago(1320), auditStatus: 'PENDING', versionTag: 'v0.2.0', model: 'Claude-Sonnet', description: '识别供应商资质与履约风险，输出风险等级与处置建议。', tags: ['法务'] },
    { id: 'app-2003', agentId: 'agent-1011', agentCode: 'recruit_screen', name: '招聘筛选智能体', displayName: '招聘筛选助手', department: '人力资源部', owner: '马丽', email: 'mali2@lenovo.com', createdAt: ago(2880), auditStatus: 'PENDING', versionTag: 'v0.1.2', model: 'Qwen-Max', description: '简历解析与岗位匹配度打分，输出面试建议。', tags: ['人事'] },
    { id: 'app-2004', agentId: 'agent-1012', agentCode: 'it_ticket_route', name: 'IT 工单路由智能体', displayName: 'IT 工单路由', department: '研发中心', owner: '郑浩', email: 'zhenghao8@lenovo.com', createdAt: ago(150), auditStatus: 'ONLINE', versionTag: 'v1.0.0', model: 'Qwen-Max', description: '自动识别 IT 工单类别并派发到对应处理组。', tags: ['IT'] },
  ];

  const workflows = [
    {
      id: 'wf-3001', workflowCode: 'wf_service_ticket', workflowName: '客户投诉处理流程', revision: 21, status: 'PUBLISHED',
      owner: '王敏', stepCount: 5, updatedAt: ago(35), goalId: 'goal-1', priority: 'P0', expectedOnline: '2026-11-15',
      description: '覆盖投诉受理、分类派单、处理与回访的闭环流程。',
      agentIds: ['agent-1001', 'agent-1006', 'agent-1008'],
      nodes: ['投诉受理', '工单分类', '派单路由', '处理跟进', '客户回访'],
      value: { saving: '16,632 h/年', coverage: '2,431 人', score: 86, roi: '1 : 3.4' },
      planAgents: [
        { id: 'agent-1001', name: '客服问答智能体', status: 'LIVE', online: '2026-06-18', dependency: '产品知识库、订单查询服务' },
        { id: 'agent-1006', name: '人事政策智能体', status: 'LIVE', online: '2026-07-02', dependency: 'HR 主数据' },
        { id: 'agent-1008', name: '文档知识智能体', status: 'LIVE', online: '2026-07-21', dependency: '知识库' },
        { id: 'agent-plan-1', name: '工单路由智能体', status: 'WIP', online: '2026-10-30', dependency: '客服问答智能体', note: '正在灰度，预计 10 月底全量。' },
        { id: 'agent-plan-2', name: '客户回访智能体', status: 'PLANNED', online: '待排期', dependency: '工单路由智能体', note: '依赖工单路由上线后方可启动。' },
      ],
    },
    {
      id: 'wf-3002', workflowCode: 'wf_contract_review', workflowName: '合同评审流程', revision: 14, status: 'PUBLISHED',
      owner: '李强', stepCount: 4, updatedAt: ago(240), goalId: 'goal-1', priority: 'P1', expectedOnline: '2026-12-20',
      description: '合同要素抽取、风险标注、法务复核与归档。',
      agentIds: ['agent-1002', 'agent-1008'],
      nodes: ['要素抽取', '风险标注', '法务复核', '合同归档'],
      value: { saving: '7,240 h/年', coverage: '320 人', score: 74, roi: '1 : 2.1' },
      planAgents: [
        { id: 'agent-1008', name: '文档知识智能体', status: 'LIVE', online: '2026-07-21', dependency: '知识库' },
        { id: 'agent-1002', name: '合同审查智能体', status: 'WIP', online: '2026-12-05', dependency: '合同模板向量库', note: '条款抽取准确率待达标（当前 91%）。' },
        { id: 'agent-plan-3', name: '法务知识智能体', status: 'SCHEDULED', online: '2027-01-20', dependency: '法规知识库' },
      ],
    },
    {
      id: 'wf-3003', workflowCode: 'wf_finance_month_end', workflowName: '月度财务结账流程', revision: 9, status: 'REVIEWING',
      owner: '赵蕾', stepCount: 6, updatedAt: ago(1560), goalId: 'goal-3', priority: 'P1', expectedOnline: '2027-03-31',
      description: '月结数据归集、试算平衡、异常核查与报表生成。',
      agentIds: ['agent-1004'],
      nodes: ['数据归集', '试算平衡', '异常核查', '调整分录', '报表生成', '复核'],
      value: { saving: '4,180 h/年', coverage: '148 人', score: 68, roi: '1 : 1.6' },
      planAgents: [
        { id: 'agent-1004', name: '财务报表智能体', status: 'SCHEDULED', online: '2027-01-10', dependency: '财务主数据、SAP 接口' },
        { id: 'agent-plan-4', name: '凭证核对智能体', status: 'PLANNED', online: '待排期', dependency: '财务报表智能体', note: '需先完成财务主数据治理。' },
        { id: 'agent-plan-5', name: '异常检测智能体', status: 'PLANNED', online: '待排期', dependency: '凭证核对智能体', note: '依赖上游凭证数据标准化。' },
      ],
    },
    {
      id: 'wf-3004', workflowCode: 'wf_rd_delivery', workflowName: '研发需求交付流程', revision: 30, status: 'PUBLISHED',
      owner: '陈涛', stepCount: 7, updatedAt: ago(20), goalId: 'goal-2', priority: 'P0', expectedOnline: '2026-10-31',
      description: '从需求澄清到发布的研发交付主流程。',
      agentIds: ['agent-1003', 'agent-1008'],
      nodes: ['需求澄清', '方案设计', '编码', '单测', '评审', '集成', '发布'],
      value: { saving: '22,400 h/年', coverage: '1,860 人', score: 91, roi: '1 : 4.7' },
      planAgents: [
        { id: 'agent-1003', name: '研发编码助手', status: 'LIVE', online: '2026-05-09', dependency: '制品库' },
        { id: 'agent-1008', name: '文档知识智能体', status: 'LIVE', online: '2026-07-21', dependency: '知识库' },
        { id: 'agent-plan-6', name: '单测生成智能体', status: 'WIP', online: '2026-10-20', dependency: '研发编码助手' },
        { id: 'agent-plan-7', name: '发布助手', status: 'PLANNED', online: '待排期', dependency: '单测生成智能体', note: '需接入发布流水线权限。' },
      ],
    },
    {
      id: 'wf-3005', workflowCode: 'wf_hr_onboarding', workflowName: '员工入职服务流程', revision: 10, status: 'DRAFT',
      owner: '周琳', stepCount: 4, updatedAt: ago(4320), goalId: 'goal-4', priority: 'P2', expectedOnline: '2027-02-28',
      description: '新员工入职登记、账号开通与政策宣讲。',
      agentIds: ['agent-1006'],
      nodes: ['入职登记', '账号开通', '政策宣讲', '导师分配'],
      value: { saving: '3,960 h/年', coverage: '540 人', score: 71, roi: '1 : 2.6' },
      planAgents: [
        { id: 'agent-1006', name: '人事政策智能体', status: 'LIVE', online: '2026-07-02', dependency: 'HR 主数据' },
        { id: 'agent-plan-8', name: 'IT 开通助手', status: 'WIP', online: '2026-11-30', dependency: 'AD 账号接口' },
      ],
    },
  ];

  // 战略目标 / 战略重点（对齐 AICT Plan：Goal / Target / Strategic Priority）
  const planGoals = [
    { id: 'goal-1', name: '客户体验提升', form: 'Goal', target: 'NPS +8', current: '+5.2', progress: 65, owner: '王敏', priority: 'P0', investment: '1,200 人日', workflowIds: ['wf-3001', 'wf-3002'] },
    { id: 'goal-2', name: '研发交付提效', form: 'Goal', target: '交付周期 -20%', current: '-12%', progress: 60, owner: '陈涛', priority: 'P0', investment: '2,600 人日', workflowIds: ['wf-3004'] },
    { id: 'goal-3', name: '财务月结自动化', form: 'Target', target: '自动化率 80%', current: '62%', progress: 78, owner: '赵蕾', priority: 'P1', investment: '480 人日', workflowIds: ['wf-3003'] },
    { id: 'goal-4', name: '员工自助服务覆盖', form: 'Strategic Priority', target: '覆盖 70% 场景', current: '41%', progress: 59, owner: '周琳', priority: 'P2', investment: '260 人日', workflowIds: ['wf-3005'] },
  ];

  // 需求入口：Demand / Product idea / Feedback 三类 intake 记录
  const planIntake = [
    { id: 'IN-2401', title: '客服投诉全流程自动化', type: 'Demand', source: '客户服务部', owner: '王敏', expectedValue: '首响时间 -30%', goalId: 'goal-1', relatedWorkflow: 'wf-3001', status: '已转流程', priority: 'P0', submittedAt: '2026-08-12', note: '来自客服中心年度痛点调研。' },
    { id: 'IN-2402', title: '合同风险自动标注', type: 'Demand', source: '法务部', owner: '李强', expectedValue: '审查工时 -45%', goalId: 'goal-1', relatedWorkflow: 'wf-3002', status: '已转流程', priority: 'P1', submittedAt: '2026-08-20', note: '与合同模板向量库建设同期推进。' },
    { id: 'IN-2403', title: '研发单测自动生成', type: 'Product idea', source: '研发中心', owner: '陈涛', expectedValue: '单测覆盖率 +25%', goalId: 'goal-2', relatedWorkflow: 'wf-3004', status: '已分流', priority: 'P0', submittedAt: '2026-09-02', note: '建议与编码助手共用模型配额。' },
    { id: 'IN-2404', title: '财务月结异常自动核查', type: 'Demand', source: '财务部', owner: '赵蕾', expectedValue: '月结周期 -2 天', goalId: 'goal-3', relatedWorkflow: 'wf-3003', status: '待评审', priority: 'P1', submittedAt: '2026-09-10', note: '依赖财务主数据治理进度。' },
    { id: 'IN-2405', title: '入职材料智能预审', type: 'Feedback', source: '人力资源部', owner: '周琳', expectedValue: '入职办理 -1.5 天', goalId: 'goal-4', relatedWorkflow: 'wf-3005', status: '已分流', priority: 'P2', submittedAt: '2026-09-14', note: 'HRBP 在使用反馈中提出。' },
    { id: 'IN-2406', title: '销售商机智能评分', type: 'Product idea', source: '销售部', owner: '吴迪', expectedValue: '赢单率 +5%', goalId: 'goal-1', relatedWorkflow: '', status: '待评审', priority: 'P1', submittedAt: '2026-09-18', note: '待评估 CRM 数据可用性。' },
    { id: 'IN-2407', title: 'IT 工单自动派发', type: 'Demand', source: '研发中心', owner: '郑浩', expectedValue: '平均响应 -18 分钟', goalId: 'goal-2', relatedWorkflow: '', status: '已转流程', priority: 'P2', submittedAt: '2026-09-20', note: '已生成 IT 工单路由智能体注册申请。' },
    { id: 'IN-2408', title: '知识库答案引用不准确', type: 'Feedback', source: '客户服务部', owner: '李强', expectedValue: '答案准确率 +8%', goalId: 'goal-1', relatedWorkflow: 'wf-3001', status: '已驳回', priority: 'P2', submittedAt: '2026-09-22', note: '属知识库切片质量问题，转数据治理跟进。' },
  ];

  // AICT Plan 表单字段参考（Reference）
  const planForms = [
    { name: 'Goal', cn: '战略目标', fields: 9, desc: '目标名称、目标值、周期、负责人、关联战略重点' },
    { name: 'Target', cn: '量化目标', fields: 7, desc: '指标、基线、目标值、统计口径、达成时间' },
    { name: 'Strategic Priority', cn: '战略重点', fields: 6, desc: '优先级、投资预算、覆盖业务域、决策人' },
    { name: 'Demand', cn: '需求', fields: 11, desc: '需求标题、来源部门、期望价值、优先级、期望上线' },
    { name: 'Product idea', cn: '产品构想', fields: 10, desc: '构想来龙去脉、目标用户、场景、可行性评估' },
    { name: 'Feedback', cn: '反馈', fields: 8, desc: '反馈来源、问题描述、影响面、处理结论' },
    { name: 'Project', cn: '项目', fields: 12, desc: '项目范围、里程碑、资源投入、交付状态' },
    { name: 'Epic', cn: '史诗', fields: 10, desc: '所属项目、业务价值、依赖、验收标准' },
  ];

  const knowledgeBases = [
    { id: 1, knowledgeId: 'KB-1001', name: '产品知识库', wsCode: 'ws_agent_ops', type: 'RAG', linkType: 'APIH', status: 1, createdBy: '张三', updatedBy: '王敏', updatedAt: '2026-09-24 10:12', description: 'ThinkPad 与 ThinkBook 全系产品参数、卖点与常见问题。' },
    { id: 2, knowledgeId: 'KB-1002', name: '售后服务知识库', wsCode: 'ws_agent_ops', type: 'RAG', linkType: 'APIH', status: 1, createdBy: '李强', updatedBy: '李强', updatedAt: '2026-09-20 16:40', description: '保修政策、退换货规则与上门服务流程。' },
    { id: 3, knowledgeId: 'KB-1003', name: '合同模板向量库', wsCode: 'ws_agent_ops', type: 'VECTOR', linkType: 'Other', status: 1, createdBy: '赵蕾', updatedBy: '赵蕾', updatedAt: '2026-09-18 09:05', description: '标准合同模板与历史审查意见向量索引。' },
    { id: 4, knowledgeId: 'KB-1004', name: '研发规范知识库', wsCode: 'ws_agent_ops', type: 'RAG', linkType: 'APIH', status: 0, createdBy: '陈涛', updatedBy: '郑浩', updatedAt: '2026-09-11 14:22', description: '编码规范、架构规约与发布检查清单。' },
    { id: 5, knowledgeId: 'KB-1005', name: '人事政策向量库', wsCode: 'ws_agent_ops', type: 'VECTOR', linkType: 'Other', status: 1, createdBy: '周琳', updatedBy: '周琳', updatedAt: '2026-09-08 11:30', description: '员工手册、假勤与福利政策的向量索引。' },
  ];

  const members = [
    { id: 1, userId: 'wangmin3', userName: '王敏', email: 'wangmin3@lenovo.com', role: 'ws_admin', wsName: '智能体运营空间', status: 1, updatedBy: 'wangmin3' },
    { id: 2, userId: 'liqiang7', userName: '李强', email: 'liqiang7@lenovo.com', role: 'ws_basic', wsName: '智能体运营空间', status: 1, updatedBy: 'wangmin3' },
    { id: 3, userId: 'chentao5', userName: '陈涛', email: 'chentao5@lenovo.com', role: 'ws_basic', wsName: '智能体运营空间', status: 0, updatedBy: 'wangmin3' },
    { id: 4, userId: 'zhaolei2', userName: '赵蕾', email: 'zhaolei2@lenovo.com', role: 'ws_basic', wsName: '智能体运营空间', status: 1, updatedBy: 'wangmin3' },
    { id: 5, userId: 'zhoulin4', userName: '周琳', email: 'zhoulin4@lenovo.com', role: 'ws_basic', wsName: '智能体运营空间', status: 1, updatedBy: 'wangmin3' },
  ];

  const tenants = [
    { id: 1, wsName: '系统管理空间', wsCode: 'acp-ws-sys', ownerId: 'zhangsan3', department: '联想集团 · 平台工程部', createdAt: '2026-06-01T09:00', status: 1, wsDescription: '平台级空间，管理空间、用户与全局策略。' },
    { id: 2, wsName: '智能体运营空间', wsCode: 'ws-agent-ops', ownerId: 'wangmin3', department: '联想集团 · 智能运营部', createdAt: '2026-06-12T14:20', status: 1, wsDescription: '面向集团职能线的智能体运营与治理空间。' },
    { id: 3, wsName: '智能客服空间', wsCode: 'ws-customer-svc', ownerId: 'liqiang7', department: '联想集团 · 客户服务部', createdAt: '2026-07-03T10:05', status: 1, wsDescription: '客服域智能体孵化与灰度发布空间。' },
    { id: 4, wsName: '研发创新空间', wsCode: 'ws-rd-lab', ownerId: 'chentao5', department: '联想集团 · 研发中心', createdAt: '2026-08-18T16:45', status: 0, wsDescription: '研发效能类智能体的试验空间。' },
  ];

  const kpiDefinitions = [
    { id: 'kpi-1', metricName: '安全评审通过率', agentId: 'agent-1001', category: 'technical', targetType: 'scalar', targetOperator: '>=', targetValue: 98, targetUnit: 'percent', enabled: true, calculationLogic: '已通过安全评审的发布版本数 ÷ 参与安全评审的发布版本总数 × 100%。', updatedAt: '2026-09-26 10:12' },
    { id: 'kpi-2', metricName: '数据准确率', agentId: 'agent-1001', category: 'technical', targetType: 'scalar', targetOperator: '>=', targetValue: 95, targetUnit: 'percent', enabled: true, calculationLogic: '抽样验证正确的输出字段数 ÷ 抽样输出字段总数 × 100%。', updatedAt: '2026-09-26 10:14' },
    { id: 'kpi-t1', metricName: '首 Token 响应时间', agentId: 'agent-1001', category: 'technical', targetType: 'scalar', targetOperator: '<=', targetValue: 1.5, targetUnit: 'seconds', enabled: true, calculationLogic: '从网关接收请求到模型返回首个 Token 的平均耗时。', updatedAt: '2026-09-26 09:40' },
    { id: 'kpi-3', metricName: '关键决策点 AI 参与率', agentId: 'agent-1007', category: 'adoption', targetType: 'period', targetOperator: '>=', targetValue: 60, targetUnit: 'percent', periodValue: 1, periodUnit: 'month', enabled: true, calculationLogic: '引用 AI 输出的关键决策次数 ÷ 关键决策总次数 × 100%。', updatedAt: '2026-09-25 15:02' },
    { id: 'kpi-4', metricName: '用户渗透率', agentId: 'agent-1006', category: 'adoption', targetType: 'period', targetOperator: '>=', targetValue: 45, targetUnit: 'percent', periodValue: 1, periodUnit: 'month', enabled: true, calculationLogic: '周活跃用户数 ÷ 具备智能体使用权限的用户总数 × 100%。', updatedAt: '2026-09-24 09:41' },
    { id: 'kpi-5', metricName: '节省工时', agentId: 'agent-1003', category: 'operational', targetType: 'period', targetOperator: '>=', targetValue: 1200, targetUnit: 'hours', periodValue: 1, periodUnit: 'week', enabled: true, calculationLogic: 'Σ（任务基准人工耗时 − 接入智能体后的实际人工耗时）。', updatedAt: '2026-09-23 18:20' },
    { id: 'kpi-6', metricName: '流程渗透率', agentId: 'agent-1001', category: 'operational', targetType: 'period', targetOperator: '>=', targetValue: 70, targetUnit: 'percent', periodValue: 1, periodUnit: 'month', enabled: false, calculationLogic: '已接入智能体的核心业务流程数 ÷ 纳入观测的核心业务流程总数 × 100%。', updatedAt: '2026-09-21 11:10' },
  ];

  const kpiMetrics = [
    { definitionId: 'kpi-1', metricName: '安全评审通过率', category: 'technical', displayValue: '100%', targetText: '目标 >= 98%', delta: '+2.4%', progress: 100, status: 'onTrack' },
    { definitionId: 'kpi-2', metricName: '数据准确率', category: 'technical', displayValue: '96.2%', targetText: '目标 >= 95%', delta: '+1.1%', progress: 100, status: 'onTrack' },
    { definitionId: 'kpi-t1', metricName: '首 Token 响应时间', category: 'technical', displayValue: '1.84s', targetText: '目标 <= 1.5秒', delta: '-6.2%', progress: 82, status: 'alert' },
    { definitionId: 'kpi-t2', metricName: 'Token 消耗量', category: 'technical', displayValue: '18.4M', targetText: '目标 1月内<=15000000数值', delta: '+8.6%', progress: 68, status: 'offTrack' },
    { definitionId: 'kpi-3', metricName: '关键决策点 AI 参与率', category: 'adoption', displayValue: '63.5%', targetText: '目标 1月内>=60%', delta: '+4.8%', progress: 100, status: 'onTrack' },
    { definitionId: 'kpi-4', metricName: '用户渗透率', category: 'adoption', displayValue: '41.8%', targetText: '目标 1月内>=45%', delta: '+2.2%', progress: 92, status: 'alert' },
    { definitionId: 'kpi-a1', metricName: '周活跃用户数', category: 'adoption', displayValue: '2,431', targetText: '目标 1周内>=2000数值', delta: '+7.3%', progress: 100, status: 'onTrack' },
    { definitionId: 'kpi-a2', metricName: '步骤级人机比例', category: 'adoption', displayValue: '3 : 7', targetText: '目标 <= 0.25数值', delta: '-1.5%', progress: 100, status: 'onTrack' },
    { definitionId: 'kpi-5', metricName: '节省工时', category: 'operational', displayValue: '1,386h', targetText: '目标 1周内>=1200小时', delta: '+12.6%', progress: 100, status: 'onTrack' },
    { definitionId: 'kpi-6', metricName: '流程渗透率', category: 'operational', displayValue: '62.4%', targetText: '目标 1月内>=70%', delta: '+3.1%', progress: 89, status: 'offTrack' },
    { definitionId: 'kpi-o1', metricName: '细粒度采用率', category: 'operational', displayValue: '74.0%', targetText: '目标 >= 80%', delta: '-0.8%', progress: 92, status: 'alert' },
  ];

  const overview = {
    totalAgents: 128, approvedCount: 96, pendingCount: 18, totalApiCount: 342,
    totalDependencyCount: 57, totalSkillCount: 486,
    departments: [{ name: '智能客服部', count: 8 }, { name: '法务部', count: 8 }, { name: '研发中心', count: 16 }, { name: '财务部', count: 8 }, { name: '市场部', count: 8 }, { name: '人力资源部', count: 8 }, { name: '销售部', count: 8 }],
    gatewayTypes: [{ name: 'AI Gateway', count: 82 }, { name: 'Agent IAM', count: 46 }, { name: 'MCP Gateway', count: 23 }],
    planStatuses: [{ name: '已规划', count: 26 }, { name: '已排期', count: 18 }, { name: '进行中', count: 31 }, { name: '已上线', count: 45 }, { name: '已废弃', count: 8 }],
    models: [{ name: 'GPT-4.1', count: 42 }, { name: 'Qwen-Max', count: 31 }, { name: 'DeepSeek-V3', count: 26 }, { name: 'Claude-Sonnet', count: 17 }, { name: 'Llama-3.1', count: 8 }, { name: '其它', count: 4 }],
  };

  const system = {
    spaceCount: 12, totalAgents: 128, pendingAgentCount: 18, publishedAgentCount: 96, totalApiCount: 342, totalSkillCount: 486,
    auditStatuses: [{ name: '草稿', count: 14 }, { name: '审批中', count: 18 }, { name: '已发布', count: 96 }],
    workspaceUsers: [{ name: '系统管理空间', count: 6 }, { name: '智能体运营空间', count: 42 }, { name: '智能客服空间', count: 28 }, { name: '研发创新空间', count: 19 }, { name: '其它空间', count: 12 }],
    workspaceAgents: [{ name: '系统管理空间', count: 8 }, { name: '智能体运营空间', count: 46 }, { name: '智能客服空间', count: 24 }, { name: '研发创新空间', count: 17 }, { name: '其它空间', count: 14 }],
  };

  const topology = {
    nodes: [
      { id: 'agent-1001', name: '客服问答智能体', type: 'agent', department: '智能客服部', planStatus: 'LIVE', auditStatus: 'PUBLISHED', runStatus: 'RUNNING', owner: '王敏', version: '1.4.2', model: 'GPT-4.1', skills: ['FAQ 问答', '工单分类'], tools: ['工单查询'], services: ['订单查询'], registered: true, description: '面向消费者业务线的智能客服助手。' },
      { id: 'agent-1006', name: '人事政策智能体', type: 'agent', department: '人力资源部', planStatus: 'LIVE', auditStatus: 'PUBLISHED', runStatus: 'RUNNING', owner: '周琳', version: '1.0.3', model: 'Qwen-Max', skills: ['政策问答'], services: ['HR 主数据'], registered: true, description: '人事政策问答与假勤计算。' },
      { id: 'agent-1007', name: '销售作战智能体', type: 'agent', department: '销售部', planStatus: 'WIP', auditStatus: 'REVIEWING', runStatus: 'RUNNING', owner: '吴迪', version: '1.2.5', model: 'GPT-4.1', skills: ['商机评分'], services: ['CRM'], registered: true, description: '商机评分与话术建议。' },
      { id: 'model-gpt41', name: 'GPT-4.1', type: 'model', description: '主对话模型。' },
      { id: 'model-qwen', name: 'Qwen-Max', type: 'model', description: '中文问答模型。' },
      { id: 'mcp-file', name: 'File MCP', type: 'mcp', tools: ['工单查询'], services: ['/api/tickets'], description: '文件读写与归档能力。' },
      { id: 'skill-faq', name: 'FAQ 问答', type: 'skill', description: '基于知识库的问答技能。' },
      { id: 'skill-ticket', name: '工单分类', type: 'skill', description: '工单类别与优先级识别。' },
      { id: 'kb-1001', name: '产品知识库', type: 'knowledgebase', description: '产品参数与卖点。' },
      { id: 'svc-order', name: '订单查询服务', type: 'service', description: '订单主数据查询。' },
      { id: 'tp-1', name: '第三方 CRM', type: 'thirdParty', description: '客户主数据依赖。' },
      { id: 'cg-1', name: '客户体验组', type: 'categoryGroup', description: '客服域智能体分组。' },
    ],
    edges: [
      ['agent-1001', 'model-gpt41'], ['agent-1001', 'skill-faq'], ['agent-1001', 'skill-ticket'],
      ['agent-1001', 'kb-1001'], ['agent-1001', 'mcp-file'], ['agent-1001', 'svc-order'],
      ['agent-1001', 'agent-1006'], ['agent-1007', 'agent-1001'], ['agent-1007', 'model-gpt41'],
      ['agent-1007', 'tp-1'], ['agent-1006', 'model-qwen'], ['agent-1006', 'cg-1'],
    ],
  };

  return { workspaces, departments, agents, applications, workflows, planGoals, planIntake, planForms, knowledgeBases, members, tenants, kpiDefinitions, kpiMetrics, overview, system, topology, cmdb: [
    { id: 'APP-100238', name: 'AI-Customer-Service', fullName: '联想智能客服平台', owner: '王敏' },
    { id: 'APP-100415', name: 'AI-Contract-Review', fullName: '法务合同智能审查', owner: '李强' },
    { id: 'APP-100512', name: 'AI-RD-Copilot', fullName: '研发编码助手', owner: '陈涛' },
  ] };
})();
